// src/app/api/news-categories/route.ts
import { NextResponse } from "next/server";
import { NEWS_CATEGORIES, NEWS_CATEGORY_DESCRIPTIONS, NEWS_CATEGORY_COLORS } from "@/constants/news-categories";
import { createApiResponse } from "@/lib/api-helpers";

// GET /api/news-categories - Hírek kategóriák listázása
export async function GET() {
  try {
    const categoriesWithDetails = NEWS_CATEGORIES.map(category => ({
      id: category,
      name: category,
      description: NEWS_CATEGORY_DESCRIPTIONS[category],
      colors: NEWS_CATEGORY_COLORS[category]
    }));

    return createApiResponse(
      categoriesWithDetails, 
      `${categoriesWithDetails.length} hírek kategória betöltve`
    );
  } catch (error) {
    console.error("[NEWS_CATEGORIES_GET]", error);
    return NextResponse.json(
      { error: "Hiba a hírek kategóriák betöltése közben" },
      { status: 500 }
    );
  }
}
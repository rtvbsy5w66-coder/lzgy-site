// __tests__/api/events.test.ts
import { POST, GET } from '@/app/api/events/route';

// Mock NextRequest for testing
class MockNextRequest {
  constructor(url, options = {}) {
    this.url = url;
    this.method = options.method || 'GET';
    this.headers = new Map();
    this.body = options.body;
  }
  
  async json() {
    return this.body;
  }
}

describe('/api/events', () => {
  describe('GET /api/events', () => {
    it('should return consistent response format', async () => {
      const response = await GET(new MockNextRequest('http://localhost:3000/api/events'));
      const data = await response.json();
      
      expect(data).toHaveProperty('success');
      expect(data).toHaveProperty('timestamp');
      expect(data).toHaveProperty('data');
      expect(data).toHaveProperty('message');
      
      expect(data.success).toBe(true);
      expect(Array.isArray(data.data)).toBe(true);
      expect(typeof data.message).toBe('string');
    });

    it('should filter upcoming events', async () => {
      const response = await GET(
        new MockNextRequest('http://localhost:3000/api/events?upcoming=true')
      );
      const data = await response.json();
      
      expect(data.success).toBe(true);
      expect(data.message).toContain('közelgő események');
    });
  });

  describe('POST /api/events', () => {
    it('should create event with valid data', async () => {
      const eventData = {
        title: 'Test Event',
        description: 'Test event description',
        location: 'Test Location',
        startDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        endDate: new Date(Date.now() + 25 * 60 * 60 * 1000).toISOString(),
        status: 'UPCOMING'
      };

      const response = await POST(
        new MockNextRequest('http://localhost:3000/api/events', {
          method: 'POST',
          body: eventData
        })
      );

      const data = await response.json();
      
      expect(data.success).toBe(true);
      expect(data.message).toBe('Sikeresen létrehozva');
      expect(data.data).toHaveProperty('title', 'Test Event');
      expect(response.status).toBe(201);
    });

    it('should validate required fields', async () => {
      const invalidData = {
        title: 'Test Event'
        // Missing required fields
      };

      const response = await POST(
        new MockNextRequest('http://localhost:3000/api/events', {
          method: 'POST',
          body: invalidData
        })
      );

      const data = await response.json();
      
      expect(data.success).toBe(false);
      expect(data.error).toBe('Validációs hibák találhatók');
      expect(response.status).toBe(400);
    });

    it('should validate event dates', async () => {
      const invalidData = {
        title: 'Test Event',
        description: 'Description',
        location: 'Location',
        startDate: new Date(Date.now() + 25 * 60 * 60 * 1000).toISOString(), // Later
        endDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()    // Earlier
      };

      const response = await POST(
        new MockNextRequest('http://localhost:3000/api/events', {
          method: 'POST',
          body: invalidData
        })
      );

      const data = await response.json();
      
      expect(data.success).toBe(false);
      expect(data.error).toContain('befejező dátum');
      expect(response.status).toBe(400);
    });
  });
});
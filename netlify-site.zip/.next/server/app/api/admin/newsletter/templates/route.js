"use strict";(()=>{var e={};e.id=1252,e.ids=[1252],e.modules={53524:e=>{e.exports=require("@prisma/client")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},17702:e=>{e.exports=require("events")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},86624:e=>{e.exports=require("querystring")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},79168:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>b,patchFetch:()=>y,requestAsyncStorage:()=>m,routeModule:()=>c,serverHooks:()=>u,staticGenerationAsyncStorage:()=>f});var i={};r.r(i),r.d(i,{GET:()=>g,POST:()=>x});var o=r(49303),s=r(88716),n=r(60670),a=r(87070),l=r(45609),d=r(6778);let p=[{id:"template-1",name:"Heti politikai \xf6sszefoglal\xf3",subject:"Heti \xf6sszefoglal\xf3 - {DATE}",category:"weekly",frequency:"heti",content:`
<div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
  <h2 style="color: #1f2937; border-bottom: 3px solid #3b82f6; padding-bottom: 10px;">
    📊 Heti politikai \xf6sszefoglal\xf3
  </h2>

  <p>Kedves {NAME}!</p>
  
  <p>\xcdme a h\xe9t legfontosabb politikai esem\xe9nyei \xe9s fejlem\xe9nyei:</p>

  <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
    <h3 style="color: #3b82f6; margin-top: 0;">🗳️ Politikai h\xedrek</h3>
    <ul style="line-height: 1.6;">
      <li><strong>[FONTOS H\xcdR 1]</strong> - [r\xe9szletek]</li>
      <li><strong>[FONTOS H\xcdR 2]</strong> - [r\xe9szletek]</li>
      <li><strong>[HELYI H\xcdR]</strong> - [V. ker\xfcleti fejlem\xe9nyek]</li>
    </ul>
  </div>

  <div style="background: #ecfdf5; padding: 20px; border-radius: 8px; margin: 20px 0;">
    <h3 style="color: #059669; margin-top: 0;">📅 K\xf6zelgő esem\xe9nyek</h3>
    <ul style="line-height: 1.6;">
      <li><strong>[ESEM\xc9NY 1]</strong> - [D\xc1TUM] - <a href="[LINK]">R\xe9szletek</a></li>
      <li><strong>[ESEM\xc9NY 2]</strong> - [D\xc1TUM] - <a href="[LINK]">Regisztr\xe1ci\xf3</a></li>
    </ul>
  </div>

  <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0;">
    <h3 style="color: #d97706; margin-top: 0;">💡 V\xe9lem\xe9nynyilv\xe1n\xedt\xe1si lehetős\xe9gek</h3>
    <p>V\xe1rjuk v\xe9lem\xe9ny\xe9t az aktu\xe1lis k\xe9rd\xe9sekről:</p>
    <ul>
      <li><a href="[POLL_LINK]">Szavaz\xe1s: [T\xc9MA]</a></li>
      <li><a href="[CONTACT_LINK]">Kapcsolatfelv\xe9tel</a></li>
    </ul>
  </div>

  <p style="margin-top: 30px;">
    K\xf6sz\xf6n\xf6m a figyelmet!<br>
    <strong>Lovas Zolt\xe1n</strong>
  </p>
</div>`,createdAt:new Date().toISOString()},{id:"template-2",name:"Esem\xe9ny megh\xedv\xf3",subject:"Megh\xedv\xf3: {EVENT_NAME} - {DATE}",category:"event",content:`
<div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
  <div style="background: linear-gradient(135deg, #3b82f6, #1d4ed8); color: white; padding: 30px; border-radius: 8px; text-align: center; margin-bottom: 20px;">
    <h1 style="margin: 0; font-size: 28px;">🎉 Megh\xedv\xf3</h1>
    <h2 style="margin: 10px 0 0 0; font-weight: normal; opacity: 0.9;">{EVENT_NAME}</h2>
  </div>

  <div style="background: #f8fafc; padding: 25px; border-radius: 8px; margin: 20px 0;">
    <h3 style="color: #1f2937; margin-top: 0;">📋 Esem\xe9ny r\xe9szletei</h3>
    <table style="width: 100%; border-collapse: collapse;">
      <tr>
        <td style="padding: 8px 0; font-weight: bold; color: #4b5563;">📅 Időpont:</td>
        <td style="padding: 8px 0;">{DATE_TIME}</td>
      </tr>
      <tr>
        <td style="padding: 8px 0; font-weight: bold; color: #4b5563;">📍 Helysz\xedn:</td>
        <td style="padding: 8px 0;">{LOCATION}</td>
      </tr>
      <tr>
        <td style="padding: 8px 0; font-weight: bold; color: #4b5563;">🎯 T\xe9ma:</td>
        <td style="padding: 8px 0;">{TOPIC}</td>
      </tr>
    </table>
  </div>

  <div style="margin: 25px 0;">
    <h3 style="color: #1f2937;">🗓️ Program</h3>
    <ul style="line-height: 1.8; padding-left: 20px;">
      <li><strong>{TIME_1}</strong> - {PROGRAM_1}</li>
      <li><strong>{TIME_2}</strong> - {PROGRAM_2}</li>
      <li><strong>{TIME_3}</strong> - {PROGRAM_3}</li>
    </ul>
  </div>

  <div style="text-align: center; margin: 30px 0;">
    <p style="margin-bottom: 20px;">Az esem\xe9ny <strong>ingyenes</strong>, de előzetes regisztr\xe1ci\xf3 sz\xfcks\xe9ges.</p>
    <a href="{REGISTRATION_LINK}" style="background: linear-gradient(135deg, #10b981, #059669); color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
      ✅ Regisztr\xe1lok
    </a>
  </div>

  <p>V\xe1rjuk szeretettel! 🤝</p>
</div>`,createdAt:new Date().toISOString()},{id:"template-3",name:"Havi besz\xe1mol\xf3",subject:"Havi besz\xe1mol\xf3 - {MONTH} {YEAR}",category:"monthly",frequency:"havi",content:`
<div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
  <h2 style="color: #1f2937; background: linear-gradient(135deg, #fbbf24, #f59e0b); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-size: 32px; text-align: center;">
    📈 {MONTH} havi besz\xe1mol\xf3
  </h2>

  <p>Kedves {NAME}!</p>
  
  <p>\xd6sszefoglalom a {MONTH} h\xf3nap legfontosabb esem\xe9nyeit \xe9s eredm\xe9nyeit:</p>

  <div style="background: #dbeafe; padding: 25px; border-radius: 8px; margin: 25px 0; border-left: 5px solid #3b82f6;">
    <h3 style="color: #1e40af; margin-top: 0;">🏛️ Parlamenti munka</h3>
    <ul style="line-height: 1.7;">
      <li><strong>Beny\xfajtott javaslatok:</strong> {PROPOSALS_COUNT} db</li>
      <li><strong>Parlamenti felsz\xf3lal\xe1sok:</strong> {SPEECHES_COUNT} db</li>
      <li><strong>Bizotts\xe1gi \xfcl\xe9sek:</strong> {COMMITTEE_MEETINGS} db</li>
    </ul>
    <p><a href="{PARLIAMENT_LINK}">📋 R\xe9szletes parlamenti aktivit\xe1s</a></p>
  </div>

  <div style="background: #ecfdf5; padding: 25px; border-radius: 8px; margin: 25px 0; border-left: 5px solid #10b981;">
    <h3 style="color: #047857; margin-top: 0;">🏘️ Helyi k\xf6z\xf6ss\xe9gi munka</h3>
    <ul style="line-height: 1.7;">
      <li><strong>Lakoss\xe1gi f\xf3rumok:</strong> {FORUMS_COUNT} db</li>
      <li><strong>Fogad\xf3\xf3r\xe1k:</strong> {OFFICE_HOURS} \xf3ra</li>
      <li><strong>Megoldott \xfcgyek:</strong> {RESOLVED_CASES} db</li>
    </ul>
  </div>

  <div style="background: #fef3c7; padding: 25px; border-radius: 8px; margin: 25px 0; border-left: 5px solid #f59e0b;">
    <h3 style="color: #d97706; margin-top: 0;">📊 Statisztik\xe1k</h3>
    <table style="width: 100%; border-collapse: collapse;">
      <tr>
        <td style="padding: 8px 0; font-weight: bold;">H\xedrlev\xe9l feliratkoz\xf3k:</td>
        <td style="padding: 8px 0; text-align: right;">{SUBSCRIBER_COUNT} fő</td>
      </tr>
      <tr>
        <td style="padding: 8px 0; font-weight: bold;">Esem\xe9ny r\xe9sztvevők:</td>
        <td style="padding: 8px 0; text-align: right;">{EVENT_PARTICIPANTS} fő</td>
      </tr>
      <tr>
        <td style="padding: 8px 0; font-weight: bold;">Online szavaz\xe1sok:</td>
        <td style="padding: 8px 0; text-align: right;">{POLL_VOTES} szavazat</td>
      </tr>
    </table>
  </div>

  <div style="background: #f3f4f6; padding: 25px; border-radius: 8px; margin: 25px 0;">
    <h3 style="color: #1f2937; margin-top: 0;">🎯 K\xf6vetkező h\xf3nap tervei</h3>
    <ul style="line-height: 1.7;">
      <li>{NEXT_MONTH_PLAN_1}</li>
      <li>{NEXT_MONTH_PLAN_2}</li>
      <li>{NEXT_MONTH_PLAN_3}</li>
    </ul>
  </div>

  <p style="margin-top: 30px; text-align: center; color: #6b7280;">
    K\xf6sz\xf6n\xf6m a bizalmat \xe9s t\xe1mogat\xe1st!<br>
    <strong style="color: #1f2937;">Lovas Zolt\xe1n</strong>
  </p>
</div>`,createdAt:new Date().toISOString()},{id:"template-4",name:"S\xfcrgős k\xf6zlem\xe9ny",subject:"\uD83D\uDEA8 S\xfcrgős: {TOPIC}",category:"urgent",content:`
<div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
  <div style="background: #fee2e2; border: 2px solid #fca5a5; border-radius: 8px; padding: 20px; margin-bottom: 25px;">
    <h2 style="color: #dc2626; margin: 0; text-align: center; font-size: 24px;">
      🚨 S\xdcRGŐS K\xd6ZLEM\xc9NY
    </h2>
  </div>

  <p>Kedves {NAME}!</p>

  <div style="background: #fef2f2; padding: 20px; border-radius: 8px; border-left: 5px solid #ef4444; margin: 20px 0;">
    <h3 style="color: #dc2626; margin-top: 0;">⚠️ {TOPIC}</h3>
    <p style="font-size: 16px; line-height: 1.6; margin: 0;">
      {URGENT_MESSAGE}
    </p>
  </div>

  <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
    <h3 style="color: #0369a1; margin-top: 0;">📋 Mit tehetsz?</h3>
    <ul style="line-height: 1.7;">
      <li>{ACTION_1}</li>
      <li>{ACTION_2}</li>
      <li>{ACTION_3}</li>
    </ul>
  </div>

  <div style="text-align: center; margin: 25px 0;">
    <a href="{ACTION_LINK}" style="background: #dc2626; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
      🎯 Azonnali cselekv\xe9s
    </a>
  </div>

  <div style="background: #f9fafb; padding: 15px; border-radius: 8px; margin: 20px 0;">
    <p style="margin: 0; color: #6b7280; font-size: 14px;">
      <strong>Kapcsolat:</strong><br>
      📧 Email: {CONTACT_EMAIL}<br>
      📞 Telefon: {CONTACT_PHONE}<br>
      🕒 Fogad\xf3\xf3ra: {OFFICE_HOURS}
    </p>
  </div>

  <p style="margin-top: 25px;">
    K\xf6sz\xf6n\xf6m a figyelmet \xe9s a gyors reag\xe1l\xe1st!<br>
    <strong>Lovas Zolt\xe1n</strong>
  </p>
</div>`,createdAt:new Date().toISOString()},{id:"template-5",name:"Szavaz\xe1si felh\xedv\xe1s",subject:"\uD83D\uDDF3️ Szavazzon: {POLL_TOPIC}",category:"poll",content:`
<div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
  <div style="background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; padding: 25px; border-radius: 8px; text-align: center; margin-bottom: 25px;">
    <h1 style="margin: 0; font-size: 26px;">🗳️ K\xf6z\xf6ss\xe9gi szavaz\xe1s</h1>
    <p style="margin: 10px 0 0 0; opacity: 0.9; font-size: 18px;">{POLL_TOPIC}</p>
  </div>

  <p>Kedves {NAME}!</p>

  <p>V\xe9lem\xe9nye fontos sz\xe1munkra! K\xe9rj\xfck, vegyen r\xe9szt a k\xf6vetkező szavaz\xe1sban:</p>

  <div style="background: #f5f3ff; padding: 25px; border-radius: 8px; margin: 25px 0; border-left: 5px solid #8b5cf6;">
    <h3 style="color: #6d28d9; margin-top: 0;">❓ K\xe9rd\xe9s</h3>
    <p style="font-size: 18px; font-weight: 500; color: #1f2937; margin: 15px 0;">
      {POLL_QUESTION}
    </p>

    <div style="background: white; padding: 20px; border-radius: 6px; margin: 15px 0;">
      <h4 style="color: #4b5563; margin-top: 0; margin-bottom: 15px;">V\xe1laszlehetős\xe9gek:</h4>
      <ul style="list-style: none; padding: 0; margin: 0;">
        <li style="padding: 8px 0; border-bottom: 1px solid #e5e7eb;">✅ {OPTION_1}</li>
        <li style="padding: 8px 0; border-bottom: 1px solid #e5e7eb;">✅ {OPTION_2}</li>
        <li style="padding: 8px 0; border-bottom: 1px solid #e5e7eb;">✅ {OPTION_3}</li>
        <li style="padding: 8px 0;">✅ {OPTION_4}</li>
      </ul>
    </div>
  </div>

  <div style="text-align: center; margin: 30px 0;">
    <a href="{POLL_LINK}" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; padding: 18px 35px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block; font-size: 16px;">
      🗳️ Szavazok most
    </a>
  </div>

  <div style="background: #ecfdf5; padding: 20px; border-radius: 8px; margin: 25px 0;">
    <h3 style="color: #047857; margin-top: 0; font-size: 16px;">ℹ️ Fontos tudnival\xf3k</h3>
    <ul style="line-height: 1.6; color: #065f46; margin: 0; font-size: 14px;">
      <li><strong>Szavaz\xe1s v\xe9ge:</strong> {DEADLINE}</li>
      <li><strong>R\xe9sztvevők:</strong> {ELIGIBLE_VOTERS}</li>
      <li><strong>Eredm\xe9ny k\xf6zz\xe9t\xe9tele:</strong> {RESULTS_DATE}</li>
      <li>A szavaz\xe1s anonim \xe9s biztons\xe1gos</li>
    </ul>
  </div>

  <p style="margin-top: 25px;">
    K\xf6sz\xf6n\xf6m a r\xe9szv\xe9telt!<br>
    <strong>Lovas Zolt\xe1n</strong>
  </p>

  <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
    <p style="margin: 0; color: #6b7280; font-size: 12px;">
      📊 <a href="{RESULTS_LINK}" style="color: #6b7280;">Eddigi eredm\xe9nyek megtekint\xe9se</a>
    </p>
  </div>
</div>`,createdAt:new Date().toISOString()}];async function g(){try{let e=await (0,l.getServerSession)(d.Lz);if(!e?.user||"ADMIN"!==e.user.role)return a.NextResponse.json({error:"Unauthorized - Admin access required"},{status:401});return a.NextResponse.json({success:!0,data:p})}catch(e){return console.error("Error fetching newsletter templates:",e),a.NextResponse.json({error:"Failed to fetch templates"},{status:500})}}async function x(e){try{let t=await (0,l.getServerSession)(d.Lz);if(!t?.user||"ADMIN"!==t.user.role)return a.NextResponse.json({error:"Unauthorized - Admin access required"},{status:401});let{name:r,subject:i,content:o,category:s="custom"}=await e.json();if(!r||!i||!o)return a.NextResponse.json({error:"Name, subject, and content are required"},{status:400});let n={id:`template-${Date.now()}`,name:r,subject:i,content:o,category:s,createdAt:new Date().toISOString()};return p.push(n),a.NextResponse.json({success:!0,data:n,message:"Template created successfully"})}catch(e){return console.error("Error creating newsletter template:",e),a.NextResponse.json({error:"Failed to create template"},{status:500})}}let c=new o.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/admin/newsletter/templates/route",pathname:"/api/admin/newsletter/templates",filename:"route",bundlePath:"app/api/admin/newsletter/templates/route"},resolvedPagePath:"/Users/lovas.zoltan/Seafile/Saj\xe1t k\xf6tet/Me, Myself and I/webpage/lovas-political-main/src/app/api/admin/newsletter/templates/route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:m,staticGenerationAsyncStorage:f,serverHooks:u}=c,b="/api/admin/newsletter/templates/route";function y(){return(0,n.patchFetch)({serverHooks:u,staticGenerationAsyncStorage:f})}},6778:(e,t,r)=>{r.d(t,{I8:()=>g,Lz:()=>p});var i=r(77234),o=r(7585),s=r(53524);let n=!1;var a=r(75571),l=r.n(a);let d=new s.PrismaClient;!function(){if(n)return;let e=["NEXTAUTH_URL","NEXTAUTH_SECRET","GOOGLE_CLIENT_ID","GOOGLE_CLIENT_SECRET","DATABASE_URL","ADMIN_EMAILS"].filter(e=>!process.env[e]);if(e.length>0)throw console.error(`Missing environment variables: ${e.join(", ")}`),Error(`Missing environment variables: ${e.join(", ")}`);console.log(`Environment variables validated at ${new Date().toISOString()}`),n=!0}();let p={debug:"true"===process.env.NEXTAUTH_DEBUG,logger:{error(e,t){console.error(`[NextAuth Error] ${new Date().toISOString()} - ${e}:`,t)},warn(e){console.warn(`[NextAuth Warning] ${new Date().toISOString()} - ${e}`)},debug(e,t){"true"===process.env.NEXTAUTH_DEBUG&&console.log(`[NextAuth Debug] ${new Date().toISOString()} - ${e}:`,t)}},adapter:(0,o.N)(d),providers:[(0,i.Z)({clientId:process.env.GOOGLE_CLIENT_ID,clientSecret:process.env.GOOGLE_CLIENT_SECRET,authorization:{params:{scope:"openid email profile",prompt:"select_account",access_type:"offline"}}})],callbacks:{signIn:async({user:e,account:t,profile:r})=>(console.log(`[SignIn Callback] Starting validation for: ${e.email}`),console.log(`[SignIn Callback] Provider: ${t?.provider}`),t?.provider==="google"&&e.email)?(console.log(`[SignIn Callback] APPROVED - Google login: ${e.email}`),!0):(console.log("[SignIn Callback] REJECTED - Invalid provider or missing email"),!1),async session({session:e,user:t,trigger:r,newSession:i}){if(console.log("[Session Callback] Creating session for user:",{sessionEmail:e.user?.email,userId:t?.id,userRole:t?.role,trigger:r}),e.user&&t){if(e.user.id=t.id,"update"!==r&&e.user.displayName)e.user.displayName=t.displayName,e.user.phoneNumber=t.phoneNumber;else try{let r=await d.user.findUnique({where:{id:t.id},select:{displayName:!0,phoneNumber:!0,role:!0,name:!0,email:!0,image:!0}});r&&(e.user.displayName=r.displayName,e.user.phoneNumber=r.phoneNumber,e.user.role=r.role)}catch(e){console.error("[Session Callback] Error fetching fresh user data:",e)}(process.env.ADMIN_EMAILS?.split(",").map(e=>e.trim())||["admin@lovaszoltan.hu","plscallmegiorgio@gmail.com"]).includes(e.user.email||"")?(e.user.role=s.User_role.ADMIN,console.log(`[Session Callback] Admin session created for: ${e.user.email}`)):(e.user.role=t.role||s.User_role.USER,console.log(`[Session Callback] User session created for: ${e.user.email}`))}return e},jwt:async({token:e,user:t})=>(t&&(e.id=t.id,(process.env.ADMIN_EMAILS?.split(",").map(e=>e.trim())||["admin@lovaszoltan.hu","plscallmegiorgio@gmail.com"]).includes(e.email||"")?e.role=s.User_role.ADMIN:e.role=t.role||s.User_role.USER,console.log(`[JWT Callback] JWT token updated for user: ${t.id} with role: ${e.role}`)),e)},session:{strategy:"database",maxAge:86400},pages:{signIn:"/admin/login",error:"/admin/login"}};l()(p);let g=()=>(0,a.getServerSession)(p)}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[8948,5972,2635],()=>r(79168));module.exports=i})();
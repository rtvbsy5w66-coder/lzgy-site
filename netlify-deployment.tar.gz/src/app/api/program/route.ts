import { NextResponse } from "next/server";

// Új kategóriák bővített programpontokkal
const PROGRAM_CATEGORIES = [
  "Szociálpolitika",
  "Oktatáspolitika", 
  "Egészségügy",
  "Közlekedés",
  "Turizmus és vendéglátás",
  "Honvédelem",
  "Rendvédelem",
  "Nyugdíjasok támogatása",
  "Integritás és elszámoltatás"
] as const;

const programPoints = [
  // SZOCIÁLPOLITIKA (8 pont)
  {
    id: "soc-1",
    title: "Családi támogatások bővítése",
    category: "Szociálpolitika",
    description: "Átfogó családtámogatási rendszer létrehozása.",
    details: "Gyermekgondozási díj emelése, ingyenes bölcsődei ellátás, családi adókedvezmények kiterjesztése minden családtípusra.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/family-support.jpg"
  },
  {
    id: "soc-2", 
    title: "Szociális lakhatás program",
    category: "Szociálpolitika",
    description: "Elérhető lakhatás biztosítása rászorulóknak.",
    details: "Önkormányzati bérlakás építés, lakhatási támogatás kiterjesztése, hajléktalanság elleni program.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "soc-3",
    title: "Munkanélküliség elleni program",
    category: "Szociálpolitika", 
    description: "Aktív foglalkoztatáspolitikai intézkedések.",
    details: "Átképzési programok, vállalkozóvá válás támogatása, munkahely-teremtési pályázatok.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/employment.jpg"
  },
  {
    id: "soc-4",
    title: "Fogyatékossággal élők támogatása",
    category: "Szociálpolitika",
    description: "Akadálymentes társadalom építése.",
    details: "Akadálymentesítési program, foglalkoztatási kvóta, támogató szolgáltatások bővítése.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "soc-5",
    title: "Gyermekszegénység felszámolása",
    category: "Szociálpolitika",
    description: "Minden gyermek számára méltó életkörülmények.",
    details: "Ingyenes tanszerek, étkeztetés kiterjesztése, szabadidős programok támogatása.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/child-poverty.jpg"
  },
  {
    id: "soc-6",
    title: "Idősek otthoni ellátása",
    category: "Szociálpolitika",
    description: "Méltóságteljes időskor otthon.",
    details: "Házi segítségnyújtás bővítése, nappali ellátás, családi gondozók támogatása.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "soc-7",
    title: "Roma integráció program",
    category: "Szociálpolitika",
    description: "Társadalmi felzárkóztatás és integráció.",
    details: "Oktatási, foglalkoztatási és lakhatási programok, kulturális sokszínűség támogatása.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "soc-8",
    title: "Női egyenjogúság és védelem",
    category: "Szociálpolitika",
    description: "Nők társadalmi helyzetének javítása.",
    details: "Családon belüli erőszak elleni védelmi rendszer, egyenlő bérezés, karriertámogatás.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/women-rights.jpg"
  },

  // OKTATÁSPOLITIKA (8 pont) 
  {
    id: "edu-1",
    title: "Digitális oktatási forradalom",
    category: "Oktatáspolitika",
    description: "21. századi készségek fejlesztése minden iskolában.",
    details: "Interaktív táblák, laptopok diákoknak, programozás oktatás, digitális kompetencia fejlesztés.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/digital-education.jpg"
  },
  {
    id: "edu-2",
    title: "Pedagógus béremelés és presztízs",
    category: "Oktatáspolitika",
    description: "Tanári pálya vonzóvá tétele.",
    details: "50%-os béremelés 3 év alatt, szakmai fejlődési lehetőségek, nyugdíj-előtakarékosság.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "edu-3",
    title: "Ingyenes felsőoktatás kiterjesztése",
    category: "Oktatáspolitika",
    description: "Elérhető egyetemi és főiskolai képzés.",
    details: "Államilag finanszírozott helyek számának duplázása, ösztöndíjrendszer bővítése.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/higher-education.jpg"
  },
  {
    id: "edu-4",
    title: "Szakképzés modernizációja",
    category: "Oktatáspolitika",
    description: "Munkaerő-piaci igényekhez igazított képzés.",
    details: "Duális képzési rendszer, modern műhelyek, vállalati partnerségek erősítése.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "edu-5",
    title: "Hátrányos helyzetű gyermekek támogatása",
    category: "Oktatáspolitika",
    description: "Egyenlő esélyek biztosítása az oktatásban.",
    details: "Felzárkóztató programok, mentorálás, extra órai támogatás, ingyenes korrepetálás.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "edu-6",
    title: "Tehetséggondozás és kiválóság",
    category: "Oktatáspolitika",
    description: "Kiemelkedő képességek fejlesztése.",
    details: "Tehetségközpontok, nemzetközi versenyek támogatása, kutatási lehetőségek diákoknak.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/talent-development.jpg"
  },
  {
    id: "edu-7",
    title: "Iskolaépületek felújítása",
    category: "Oktatáspolitika",
    description: "Korszerű tanulási környezet minden gyermeknek.",
    details: "Energetikai felújítás, akadálymentesítés, modern laboratóriumok, sportlétesítmények.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "edu-8",
    title: "Élethosszig tartó tanulás",
    category: "Oktatáspolitika",
    description: "Felnőttkori képzési lehetőségek bővítése.",
    details: "Távoktatási platformok, szakmai átképzések, nyelvi kurzusok, számítógépes ismeretek.",
    priority: 2,
    status: "tervezett"
  },

  // EGÉSZSÉGÜGY (8 pont)
  {
    id: "health-1",
    title: "Várólisták teljes felszámolása",
    category: "Egészségügy",
    description: "Sürgős ellátás minden beteg számára.",
    details: "Kapacitásbővítés, több orvos és ápoló, modern berendezések, hatékonyabb működés.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/healthcare-waiting.jpg"
  },
  {
    id: "health-2",
    title: "Egészségügyi dolgozók béremelése",
    category: "Egészségügy", 
    description: "Méltó fizetés az egészségügyben dolgozóknak.",
    details: "Orvosi és ápolói bérek európai szintre emelése, szakdolgozói pótlékok növelése.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "health-3",
    title: "Megelőzés és egészségfejlesztés",
    category: "Egészségügy",
    description: "A betegségek megelőzése a gyógyításnál.",
    details: "Ingyenes szűrővizsgálatok, egészséges életmód programok, sport és táplálkozási tanácsadás.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/prevention.jpg"
  },
  {
    id: "health-4",
    title: "Vidéki egészségügyi ellátás",
    category: "Egészségügy",
    description: "Egyenlő hozzáférés az egész országban.",
    details: "Körzeti orvosi rendelők korszerűsítése, mobil egészségügyi szolgáltatások, távdiagnosztika.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "health-5",
    title: "Mentálhigiénés szolgáltatások",
    category: "Egészségügy",
    description: "Lelki egészség támogatása minden korosztálynak.",
    details: "Pszichológiai tanácsadás bővítése, krízisintervenciós szolgálatok, stressz-kezelési programok.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "health-6",
    title: "Gyógyszerár-támogatás bővítése",
    category: "Egészségügy",
    description: "Elérhető gyógyszerek minden beteg számára.",
    details: "Újabb gyógyszerek támogatott listára vétele, krónikus betegek extra támogatása.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/medicine-support.jpg"
  },
  {
    id: "health-7",
    title: "Kórházi infrastruktúra fejlesztés",
    category: "Egészségügy",
    description: "Korszerű egészségügyi létesítmények.",
    details: "MR és CT készülékek, műtők modernizálása, betegszállítás fejlesztése, parkolási problémák megoldása.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "health-8",
    title: "Digitális egészségügy",
    category: "Egészségügy",
    description: "Technológia az egészségügy szolgálatában.",
    details: "Elektronikus egészségügyi karton, online időpontfoglalás, telemedicina szolgáltatások.",
    priority: 2,
    status: "tervezett"
  },

  // KÖZLEKEDÉS (8 pont)
  {
    id: "transport-1",
    title: "Tömegközlekedés ingyenessé tétele",
    category: "Közlekedés",
    description: "Fenntartható és elérhető közlekedés mindenkinek.",
    details: "Helyi járatok ingyenessé tétele, vasúti közlekedés támogatása, környezetbarát megoldások.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/free-transport.jpg"
  },
  {
    id: "transport-2",
    title: "Elektromos közlekedés támogatása",
    category: "Közlekedés",
    description: "Zöld közlekedési alternatívák fejlesztése.",
    details: "Elektromos buszok beszerzése, töltőhálózat kiépítése, elektromos autók vásárlási támogatása.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "transport-3",
    title: "Vidéki közlekedés fejlesztése",
    category: "Közlekedés",
    description: "Kistelepülések közlekedési kapcsolatainak javítása.",
    details: "Helyközi járatok gyakoriságának növelése, kerékpárutak kiépítése, falubusz szolgáltatás.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/rural-transport.jpg"
  },
  {
    id: "transport-4",
    title: "Vasútfejlesztési program",
    category: "Közlekedés",
    description: "Korszerű és gyors vasúti közlekedés.",
    details: "Pályafelújítások, új szerelvények, utazási idők csökkentése, állomások modernizálása.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "transport-5",
    title: "Kerékpáros infrastruktúra",
    category: "Közlekedés",
    description: "Biztonságos kerékpározás városi és vidéki területeken.",
    details: "Kerékpársávok hálózata, B+R parkolók, kerékpárkölcsönző rendszerek, biztonsági kampányok.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "transport-6",
    title: "Közlekedési dugók felszámolása",
    category: "Közlekedés",
    description: "Hatékony városi közlekedési rendszer.",
    details: "Intelligens közlekedésirányítás, körforgalmak építése, elkerülő utak, dugódíj bevezetése.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/traffic-solution.jpg"
  },
  {
    id: "transport-7",
    title: "Közlekedésbiztonság javítása",
    category: "Közlekedés",
    description: "Zéró tolerancia a közlekedési balesetekkel szemben.",
    details: "Sebességkorlátozás betartatása, gyalogátkelők biztonságossá tétele, iskolai közlekedésoktatás.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "transport-8",
    title: "Logisztikai központok fejlesztése",
    category: "Közlekedés",
    description: "Hatékony áruszállítási rendszer.",
    details: "Intermodális csomópontok, teherforgalom optimalizálása, kamionpályák kijelölése.",
    priority: 2,
    status: "tervezett"
  },

  // TURIZMUS ÉS VENDÉGLÁTÁS (8 pont)
  {
    id: "tourism-1", 
    title: "Kulturális turizmus fejlesztése",
    category: "Turizmus és vendéglátás",
    description: "Magyarország kulturális kincseinek bemutatása.",
    details: "Múzeumi és kulturális helyszínek fejlesztése, interaktív kiállítások, kulturális útvonalak.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/cultural-tourism.jpg"
  },
  {
    id: "tourism-2",
    title: "Vidéki turizmus támogatása", 
    category: "Turizmus és vendéglátás",
    description: "Falusi és ökoturizmus fellendítése.",
    details: "Panzió és vendégház fejlesztési támogatások, természetjáró utak, gasztronómiai fesztiválok.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "tourism-3",
    title: "Gyógyturizmus erősítése",
    category: "Turizmus és vendéglátás", 
    description: "Egészségturizmus világszínvonalra emelése.",
    details: "Fürdők modernizálása, wellness szolgáltatások bővítése, orvosi turizmus fejlesztése.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/spa-tourism.jpg"
  },
  {
    id: "tourism-4",
    title: "Vendéglátás minőségjavítása",
    category: "Turizmus és vendéglátás",
    description: "Magas színvonalú szolgáltatások minden vendég számára.",
    details: "Szakmai képzések, minősítési rendszerek, helyi termékek előtérbe helyezése.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "tourism-5",
    title: "Fesztiválturizmus támogatása",
    category: "Turizmus és vendéglátás",
    description: "Kulturális és zenei események népszerűsítése.",
    details: "Fesztiválszervezés támogatása, infrastruktúra fejlesztés, nemzetközi marketing.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "tourism-6",
    title: "Borturizmus fejlesztése",
    category: "Turizmus és vendéglátás",
    description: "Magyar borok és borvidékek népszerűsítése.",
    details: "Borúti fejlesztések, pincelátogatási programok, borfesztiválok támogatása.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/wine-tourism.jpg"
  },
  {
    id: "tourism-7",
    title: "Turisztikai infrastruktúra",
    category: "Turizmus és vendéglátás",
    description: "Korszerű fogadási feltételek kialakítása.",
    details: "Szálláshelyek fejlesztése, turista információs központok, látogatóbarát környezet.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "tourism-8",
    title: "Digitális turisztikai platform",
    category: "Turizmus és vendéglátás",
    description: "Online turisztikai szolgáltatások fejlesztése.", 
    details: "Egységes foglalási rendszer, mobil applikáció, virtuális túrák, QR-kódos információs rendszer.",
    priority: 2,
    status: "tervezett"
  },

  // HONVÉDELEM (8 pont)
  {
    id: "defense-1",
    title: "Katonai technológia modernizálása",
    category: "Honvédelem",
    description: "21. századi védelmi képességek kialakítása.",
    details: "Korszerű fegyverrendszerek, dróntechnológia, kibervédelmi kapacitások fejlesztése.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/military-tech.jpg"
  },
  {
    id: "defense-2",
    title: "Katonai szolgálat vonzóvá tétele",
    category: "Honvédelem",
    description: "Professzionális és motivált honvédség építése.",
    details: "Katonai bérek emelése, lakhatási támogatás, karrierfejlesztési lehetőségek, családi juttatások.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "defense-3",
    title: "Veteránok támogatási program",
    category: "Honvédelem",
    description: "Méltó elismerés a szolgálatot teljesítőknek.",
    details: "Egészségügyi ellátás, pszichológiai támogatás, átképzési programok, veterán klub támogatás.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "defense-4",
    title: "Polgári védelem erősítése",
    category: "Honvédelem",
    description: "Katasztrófahelyzetek elleni felkészültség javítása.",
    details: "Lakossági tájékoztatás, gyakorlatok szervezése, mentőfelszerelések, krízishelyzeti protokollok.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/civil-defense.jpg"
  },
  {
    id: "defense-5",
    title: "Katonai oktatás és kiképzés",
    category: "Honvédelem",
    description: "Magas színvonalú katonai szakemberek képzése.",
    details: "Katonai akadémia fejlesztése, nemzetközi együttműködések, szimulációs technológiák.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "defense-6",
    title: "Határvédelmi rendszer",
    category: "Honvédelem",
    description: "Biztonságos és ellenőrzött határok.",
    details: "Technológiai fejlesztések, határőrség megerősítése, nemzetközi együttműködés.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "defense-7",
    title: "Katonai egészségügy fejlesztése",
    category: "Honvédelem",
    description: "Egészségügyi ellátás katonák és családjaik számára.",
    details: "Katonai kórházak korszerűsítése, preventív egészségügyi programok, sportegészségügy.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "defense-8",
    title: "NATO és EU védelmi együttműködés",
    category: "Honvédelem",
    description: "Nemzetközi védelmi szövetségek erősítése.",
    details: "Közös gyakorlatok, technológiai együttműködés, információmegosztás, közös beszerzések.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/nato-cooperation.jpg"
  },

  // RENDVÉDELEM (8 pont)
  {
    id: "police-1",
    title: "Közbiztonsági szolgáltatások bővítése",
    category: "Rendvédelem",
    description: "Biztonságos közterek minden állampolgár számára.",
    details: "Több rendőr az utcákon, járőrszolgálat megerősítése, térfigyelő rendszerek kiépítése.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/public-safety.jpg"
  },
  {
    id: "police-2",
    title: "Kiberbűnözés elleni küzdelem",
    category: "Rendvédelem",
    description: "Digitális biztonság és adatvédelem.",
    details: "Speciális kiberbűnügyi egységek, online csalások elleni védelem, digitális kompetencia fejlesztés.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "police-3",
    title: "Kábítószer-ellenes program",
    category: "Rendvédelem",
    description: "Drogmentes társadalom építése.",
    details: "Megelőzési programok iskolákban, rehabilitációs központok, kereskedelem elleni hatékonyabb fellépés.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/anti-drug.jpg"
  },
  {
    id: "police-4",
    title: "Rendőri munka modernizálása",
    category: "Rendvédelem",
    description: "Korszerű eszközök és módszerek a rendvédelemben.",
    details: "Testfelvevő kamerák, modernebb járművek, kommunikációs eszközök, adatbázis-fejlesztés.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "police-5",
    title: "Áldozatvédelmi szolgáltatások",
    category: "Rendvédelem",
    description: "Bűncselekmények áldozatainak támogatása.",
    details: "Jogi segítségnyújtás, pszichológiai támogatás, családon belüli erőszak elleni védelem.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "police-6",
    title: "Közösségi rendőrség",
    category: "Rendvédelem",
    description: "Rendőrség és lakosság közötti bizalom erősítése.",
    details: "Körzeti megbízottak szerepének erősítése, lakossági fórumok, megelőzési programok.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/community-police.jpg"
  },
  {
    id: "police-7",
    title: "Igazságszolgáltatás gyorsítása",
    category: "Rendvédelem",
    description: "Hatékony és gyors bírósági eljárások.",
    details: "Digitális peres eljárások, bírósági infrastruktúra fejlesztése, várakozási idők csökkentése.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "police-8",
    title: "Bűnmegelőzési programok",
    category: "Rendvédelem",
    description: "Megelőzés a büntetés helyett.",
    details: "Fiatalkorúak programjai, konfliktuskezelési tréningek, szomszédsági őrjáratok támogatása.",
    priority: 2,
    status: "tervezett"
  },

  // NYUGDÍJASOK TÁMOGATÁSA (8 pont)
  {
    id: "pension-1",
    title: "Nyugdíjemelési program",
    category: "Nyugdíjasok támogatása",
    description: "Méltó megélhetés biztosítása minden nyugdíjasnak.",
    details: "Minimálnyugdíj jelentős emelése, inflációkövető indexálás, nyugdíjprémium kiterjesztése.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/pension-increase.jpg"
  },
  {
    id: "pension-2",
    title: "Idősellátási szolgáltatások",
    category: "Nyugdíjasok támogatása",
    description: "Átfogó gondoskodás az idős korosztály számára.",
    details: "Házi segítségnyújtás, nappali ellátó központok, szociális étkeztetés bővítése.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "pension-3",
    title: "Egészségügyi támogatás időseknek",
    category: "Nyugdíjasok támogatása",
    description: "Speciális egészségügyi ellátás nyugdíjasok számára.",
    details: "Ingyenes szűrővizsgálatok, gyógyszer-támogatás, geriátriai szakellátás fejlesztése.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/elderly-health.jpg"
  },
  {
    id: "pension-4",
    title: "Aktív időskor programok",
    category: "Nyugdíjasok támogatása",
    description: "Tartalmas és aktív nyugdíjas évek.",
    details: "Idősek klubjai, számítógépes tanfolyamok, kulturális programok, életmód-tanácsadás.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "pension-5",
    title: "Lakhatási támogatás időseknek",
    category: "Nyugdíjasok támogatása",
    description: "Biztonságos és komfortos otthon minden idős ember számára.",
    details: "Lakásfelújítási támogatás, akadálymentesítés, idősek háza építési program.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "pension-6",
    title: "Nagyszülői támogatás",
    category: "Nyugdíjasok támogatása",
    description: "Elismerés a családban betöltött szerepért.",
    details: "Nagyszülői gyed kiterjesztése, unokákkal való időtöltés támogatása, három generációs programok.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/grandparents.jpg"
  },
  {
    id: "pension-7",
    title: "Digitális befogadás",
    category: "Nyugdíjasok támogatása",
    description: "Idősek digitális világba való bekapcsolása.",
    details: "Ingyenes számítógép- és internet-tanfolyamok, tablet-támogatás, online ügyintézés segítése.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "pension-8",
    title: "Közlekedési kedvezmények",
    category: "Nyugdíjasok támogatása",
    description: "Mobilitás biztosítása kedvezményes áron.",
    details: "Ingyenes helyi közlekedés, kedvezményes vonatjegyek, időseknek szánt különjáratok.",
    priority: 2,
    status: "tervezett"
  },

  // INTEGRITÁS ÉS ELSZÁMOLTATÁS (9 kategóriás név)
  {
    id: "integrity-1",
    title: "Átlátható közbeszerzési rendszer",
    category: "Integritás és elszámoltatás",
    description: "Korrupciómentes állami megrendelések.",
    details: "Nyílt versenyek, független bizottságok, közbeszerzési adatok publikus hozzáférése.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/transparent-procurement.jpg"
  },
  {
    id: "integrity-2",
    title: "Whistleblower védelem",
    category: "Integritás és elszámoltatás",
    description: "Visszaéléseket bejelentők védelme.",
    details: "Anonim bejelentési rendszer, jogi védelem, ösztönző rendszer, retorzió elleni védelem.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "integrity-3",
    title: "Vagyonnyilatkozatok nyilvánossága",
    category: "Integritás és elszámoltatás",
    description: "Tiszta politikai élet biztosítása.",
    details: "Közhivatalnokok vagyoni helyzetének nyilvános ellenőrizhetősége, családtagokra kiterjedően.",
    priority: 1,
    status: "tervezett",
    imageUrl: "/images/programs/asset-declaration.jpg"
  },
  {
    id: "integrity-4",
    title: "Független korrupcióellenes hivatal",
    category: "Integritás és elszámoltatás",
    description: "Szakmai alapon működő ellenőrző szervezet.",
    details: "Politikailag független vezetés, széles körű vizsgálati jogkör, nyilvános jelentések.",
    priority: 1,
    status: "tervezett"
  },
  {
    id: "integrity-5",
    title: "Közpénzek használatának átláthatósága",
    category: "Integritás és elszámoltatás",
    description: "Minden forint felhasználásának nyomon követhetősége.",
    details: "Online közkiadás-adatbázis, valós idejű beszámolók, polgári ellenőrzési lehetőségek.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "integrity-6",
    title: "Etikai kódexek betartatása",
    category: "Integritás és elszámoltatás",
    description: "Magas erkölcsi mércék a közszférában.",
    details: "Közhivatalnokok etikai képzése, etikai bizottságok megerősítése, szankciók alkalmazása.",
    priority: 2,
    status: "tervezett"
  },
  {
    id: "integrity-7",
    title: "Lobbytevékenység szabályozása",
    category: "Integritás és elszámoltatás",
    description: "Átlátható érdekérvényesítési folyamatok.",
    details: "Lobbisták nyilvántartása, találkozók dokumentálása, döntéshozatali folyamatok transparenciája.",
    priority: 2,
    status: "tervezett",
    imageUrl: "/images/programs/lobby-regulation.jpg"
  },
  {
    id: "integrity-8",
    title: "Nemzetközi korrupcióellenes együttműködés",
    category: "Integritás és elszámoltatás",
    description: "Határon átnyúló korrupciós ügyek felderítése.",
    details: "GRECO és OECD ajánlások implementálása, nemzetközi adatbázisok használata, együttműködési megállapodások.",
    priority: 2,
    status: "tervezett"
  }
];

export async function GET() {
  return NextResponse.json(programPoints);
}

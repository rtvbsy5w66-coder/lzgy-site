"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Users, Award, Play, Calendar, BookOpen, CheckCircle } from "lucide-react";
import { useThemeColors } from "@/context/ThemeContext";
import { Quiz } from "@/types/quiz";

const QuizListPage = () => {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const colors = useThemeColors();
  const { data: session } = useSession();
  
  // Detect if we're in dark mode
  const isDarkMode = colors.bg === '#0f172a' || colors.bg === '#1e293b' || colors.cardBg.includes('#1e293b') || colors.cardBg.includes('#0f172a');

  useEffect(() => {
    fetchPublicQuizzes();
  }, []);

  const fetchPublicQuizzes = async () => {
    try {
      const response = await fetch('/api/quizzes?status=PUBLISHED');
      if (!response.ok) throw new Error('Failed to fetch quizzes');
      const data = await response.json();
      setQuizzes(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const formatDuration = (minutes?: number) => {
    if (!minutes) return "Időlimit nélkül";
    if (minutes < 60) return `${minutes} perc`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}ó ${mins > 0 ? `${mins}p` : ''}`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen" style={{ backgroundColor: colors.bg, color: colors.text }}>
        <div className="max-w-6xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <div className="h-12 bg-gray-200 rounded w-1/3 mx-auto mb-4 animate-pulse"></div>
            <div className="h-6 bg-gray-200 rounded w-1/2 mx-auto animate-pulse"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <Card key={item} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                    <div className="h-10 bg-gray-200 rounded"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: colors.bg, color: colors.text }}>
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Interaktív Kvízek
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Tesztelje tudását különböző témákban! Vegyen részt interaktív kvízeinkben és mérheti fel politikai, társadalmi ismereteit.
          </p>
        </div>

        {/* Error State */}
        {error && (
          <Card className="max-w-md mx-auto mb-8 border-red-200 bg-red-50">
            <CardContent className="pt-6 text-center">
              <p className="text-red-600 mb-4">Hiba történt: {error}</p>
              <Button onClick={fetchPublicQuizzes}>
                Újratöltés
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Empty State */}
        {!error && quizzes.length === 0 && (
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center">
              <Award className="h-16 w-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-semibold mb-2">Még nincsenek elérhető kvízek</h3>
              <p className="text-gray-600">Hamarosan új kvízekkel bővítjük a kínálatunkat!</p>
            </CardContent>
          </Card>
        )}

        {/* Quiz Grid */}
        {!error && quizzes.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzes.map((quiz, index) => {
              const hasCompleted = (quiz as any).hasCompleted;
              
              return (
                <Card key={quiz.id} className="hover:shadow-xl transition-all duration-300 group">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <CardTitle className="text-xl mb-2 group-hover:text-blue-600 transition-colors">
                          {quiz.title}
                        </CardTitle>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {hasCompleted && session?.user && (
                            <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
                              <CheckCircle className="h-3 w-3" />
                              Kitöltve
                            </Badge>
                          )}
                          
                          {quiz.category && (
                            <Badge 
                              
                              className="mb-2"
                              style={{ borderColor: colors.accent }}
                            >
                              <BookOpen className="h-3 w-3 mr-1" />
                              {quiz.category}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  
                  {quiz.description && (
                    <p className="text-gray-600 text-sm line-clamp-3 leading-relaxed">
                      {quiz.description}
                    </p>
                  )}
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    {/* Quiz Stats */}
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Award className="h-4 w-4" />
                        <span>{quiz.questions?.length || 0} kérdés</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        <span>{quiz._count?.results || 0} kitöltés</span>
                      </div>
                    </div>

                    {/* User's result info */}
                    {hasCompleted && (quiz as any).userResult && (
                      <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
                        <div className="flex items-center gap-2 text-green-800 dark:text-green-200">
                          <CheckCircle className="h-4 w-4" />
                          <span className="text-sm font-medium">Az Ön eredménye:</span>
                        </div>
                        <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                          {(quiz as any).userResult.percentage}% ({(quiz as any).userResult.score} pont)
                        </p>
                        <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                          Kitöltve: {new Date((quiz as any).userResult.completedAt).toLocaleDateString('hu-HU')}
                        </p>
                      </div>
                    )}

                    {/* Quiz Details */}
                    <div className="space-y-2 text-sm">
                      {quiz.timeLimit && (
                        <div className="flex items-center gap-2 text-orange-600">
                          <Clock className="h-4 w-4" />
                          <span>{formatDuration(quiz.timeLimit)}</span>
                        </div>
                      )}
                      
                      {quiz.maxAttempts && (
                        <div className="flex items-center gap-2 text-blue-600">
                          <Calendar className="h-4 w-4" />
                          <span>Maximum {quiz.maxAttempts} próbálkozás</span>
                        </div>
                      )}

                      {quiz.showResults && (
                        <div className="text-green-600 text-xs">
                          ✓ Azonnali eredményekkel
                        </div>
                      )}
                    </div>

                    {/* Action Buttons - TESZTELT STÍLUSOKKAL */}
                    <div 
                      className="quiz-button-container" 
                      style={{
                        paddingTop: '32px',
                        borderTop: `1px solid ${colors.border}`,
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '24px'
                      }}
                    >
                      {hasCompleted ? (
                        // User has completed - show both options with clear hierarchy
                        <>
                          {/* Primary Action: View Quiz Results & Leaderboard */}
                          <Link href={`/kviz/${quiz.id}/results`}>
                            <button
                              className="quiz-button-primary"
                              style={{
                                width: '100%',
                                height: '56px',
                                fontSize: '16px',
                                fontWeight: '600',
                                borderRadius: '12px',
                                border: 'none',
                                outline: 'none',
                                cursor: 'pointer',
                                transition: 'all 0.3s ease',
                                background: colors.gradient,
                                color: colors.accent,
                                boxShadow: `0 6px 20px ${colors.gradientFrom}30`,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '12px'
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.boxShadow = `0 10px 30px ${colors.gradientFrom}40`;
                                e.currentTarget.style.transform = 'translateY(-2px) scale(1.02)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.boxShadow = `0 6px 20px ${colors.gradientFrom}30`;
                                e.currentTarget.style.transform = 'translateY(0px) scale(1)';
                              }}
                            >
                              <CheckCircle className="h-5 w-5" />
                              Eredmények megtekintése
                            </button>
                          </Link>
                          
                          {/* Secondary Action: Retake Quiz */}
                          <Link href={session ? `/kviz/${quiz.id}?retake=true` : `/login?callbackUrl=${encodeURIComponent(`/kviz/${quiz.id}`)}`}>
                            <button
                              className="quiz-button-secondary"
                              style={{
                                width: '100%',
                                height: '56px',
                                fontSize: '16px',
                                fontWeight: '600',
                                borderRadius: '12px',
                                border: 'none',
                                outline: 'none',
                                cursor: 'pointer',
                                transition: 'all 0.3s ease',
                                background: colors.gradient,
                                color: colors.accent,
                                boxShadow: `0 6px 20px ${colors.gradientFrom}30`,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '12px'
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.boxShadow = `0 10px 30px ${colors.gradientFrom}40`;
                                e.currentTarget.style.transform = 'translateY(-2px) scale(1.02)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.boxShadow = `0 6px 20px ${colors.gradientFrom}30`;
                                e.currentTarget.style.transform = 'translateY(0px) scale(1)';
                              }}
                            >
                              <Play className="h-5 w-5" />
                              Kitöltöm újra
                            </button>
                          </Link>
                        </>
                      ) : (
                        // User hasn't completed yet - single primary action
                        <Link href={session ? `/kviz/${quiz.id}` : `/login?callbackUrl=${encodeURIComponent(`/kviz/${quiz.id}`)}`}>
                          <button
                            className="quiz-button-start"
                            style={{
                              width: '100%',
                              height: '56px',
                              fontSize: '16px',
                              fontWeight: '600',
                              borderRadius: '12px',
                              border: 'none',
                              outline: 'none',
                              cursor: 'pointer',
                              transition: 'all 0.3s ease',
                              background: colors.gradient,
                              color: colors.accent,
                              boxShadow: `0 6px 20px ${colors.gradientFrom}30`,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              gap: '12px'
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.boxShadow = `0 10px 30px ${colors.gradientFrom}40`;
                              e.currentTarget.style.transform = 'translateY(-2px) scale(1.02)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.boxShadow = `0 6px 20px ${colors.gradientFrom}30`;
                              e.currentTarget.style.transform = 'translateY(0px) scale(1)';
                            }}
                          >
                            <Play className="h-5 w-5" />
                            {session ? 'Kitöltöm' : 'Bejelentkezés szükséges'}
                          </button>
                        </Link>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
              );
            })}
          </div>
        )}

        {/* Call to Action */}
        {!error && quizzes.length > 0 && (
          <div className="mt-16 text-center">
            <Card className="max-w-2xl mx-auto" style={{ borderColor: colors.accent }}>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-2">Több kvíz következik!</h3>
                <p className="text-gray-600 mb-4">
                  Rendszeresen bővítjük kvíz kínálatunkat új témákkal és izgalmas kérdésekkel.
                </p>
                <p className="text-sm text-gray-500">
                  Kövesse oldalmunkat a legfrissebb kvízekért!
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizListPage;
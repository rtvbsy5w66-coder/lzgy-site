-- MySQL dump 10.13  Distrib 9.0.1, for macos14.7 (x86_64)
--
-- Host: localhost    Database: lovas_political
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Program`
--

DROP TABLE IF EXISTS `Program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Program` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` int NOT NULL,
  `status` enum('PLANNED','IN_PROGRESS','COMPLETED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PLANNED',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Program`
--

LOCK TABLES `Program` WRITE;
/*!40000 ALTER TABLE `Program` DISABLE KEYS */;
INSERT INTO `Program` VALUES ('cm5lgr4930004l9onadp0u37r','Zöld energia program','Környezetvédelem','A megújuló energiaforrások támogatása és fejlesztése.','Célunk a napenergia és szélenergia beruházások támogatása, energia-hatékony megoldások bevezetése a közintézményekben.',1,'IN_PROGRESS','2025-01-06 19:57:30.568','2025-01-06 19:57:30.568'),('cm5lgr4a10005l9onyj8nteoq','Háztartási napelem program','Környezetvédelem','Lakossági napelem telepítések támogatása.','Kedvezményes hitelkonstrukció és állami támogatás napelem rendszerek telepítéséhez.',2,'PLANNED','2025-01-06 19:57:30.602','2025-01-06 19:57:30.602'),('cm5lgr4a40006l9ondsxs3h8z','Energiahatékonysági felújítások','Környezetvédelem','Lakóépületek energetikai korszerűsítése.','Nyílászárócsere, szigetelés és fűtéskorszerűsítés támogatása a lakosság számára.',1,'IN_PROGRESS','2025-01-06 19:57:30.604','2025-01-06 19:57:30.604'),('cm5lgr4a60007l9onr80gp8a8','Digitális oktatás fejlesztése','Oktatás','Modern oktatási eszközök és módszerek bevezetése.','Iskolák digitális eszközökkel való felszerelése, tanárok továbbképzése.',2,'PLANNED','2025-01-06 19:57:30.607','2025-01-06 19:57:30.607'),('cm5lgr4a80008l9on60virupz','Egészségügyi modernizáció','Egészségügy','Kórházak és rendelők fejlesztése, várólisták csökkentése.','Modern orvosi eszközök beszerzése, egészségügyi dolgozók béremelése.',1,'IN_PROGRESS','2025-01-06 19:57:30.608','2025-01-06 19:57:30.608'),('cm5lgr4aa0009l9onc76iv5x4','Lakhatási program','Szociális ügyek','Megfizethető lakhatás biztosítása a fiatalok számára.','Első lakás program indítása, bérlakás építési program.',2,'PLANNED','2025-01-06 19:57:30.610','2025-01-06 19:57:30.610'),('cm5m70a6k0000mbuyhk2osgb1','Városi kerékpárút hálózat','Infrastruktúra','Biztonságos kerékpáros közlekedés fejlesztése.','A projekt célja egy átfogó kerékpárút-hálózat kiépítése, amely összeköti a város főbb pontjait.',1,'IN_PROGRESS','2025-01-07 08:12:28.172','2025-01-07 13:05:28.345');
/*!40000 ALTER TABLE `Program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SavedTheme`
--

DROP TABLE IF EXISTS `SavedTheme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SavedTheme` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `fromColor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `toColor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `textColor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isPreset` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SavedTheme`
--

LOCK TABLES `SavedTheme` WRITE;
/*!40000 ALTER TABLE `SavedTheme` DISABLE KEYS */;
INSERT INTO `SavedTheme` VALUES ('cm5ks9cq700005i620k5rkcfi','Kék-Zöld Modern','Modern és friss színvilág, tökéletes digitális tartalmakhoz','#6DAEF0','#8DEBD1','#FFFFFF',1,'2025-01-06 08:31:50.959','2025-01-06 08:31:50.959'),('cm5ks9cr700015i62tve4uagh','Lila Elegáns','Elegáns, királyi megjelenés különleges alkalmakra','#6D28D9','#8B5CF6','#FFFFFF',1,'2025-01-06 08:31:50.996','2025-01-06 08:31:50.996'),('cm5ks9cr900025i62ccvz7fsv','Sötétkék Professzionális','Komoly, megbízható megjelenés üzleti tartalmakhoz','#1E3A8A','#3B82F6','#FFFFFF',1,'2025-01-06 08:31:50.998','2025-01-06 08:31:50.998'),('cm5ks9crd00035i62f2mmzi37','Meleg Narancssárga','Energikus, barátságos színvilág közösségi tartalmakhoz','#EA580C','#FB923C','#FFFFFF',1,'2025-01-06 08:31:51.001','2025-01-06 08:31:51.001'),('cm5l2dtj60000jaz0ip6y1zke','Kék-Zöld Modern','Modern és friss színvilág, tökéletes digitális tartalmakhoz','#6DAEF0','#8DEBD1','#FFFFFF',1,'2025-01-06 13:15:15.519','2025-01-06 13:15:15.519'),('cm5l2dtm00001jaz0klkby3tk','Lila Elegáns','Elegáns, királyi megjelenés különleges alkalmakra','#6D28D9','#8B5CF6','#FFFFFF',1,'2025-01-06 13:15:15.624','2025-01-06 13:15:15.624'),('cm5l2dtm40002jaz0p74sy6vr','Sötétkék Professzionális','Komoly, megbízható megjelenés üzleti tartalmakhoz','#1E3A8A','#3B82F6','#FFFFFF',1,'2025-01-06 13:15:15.628','2025-01-06 13:15:15.628'),('cm5l2dtm70003jaz0q0lhy0lm','Meleg Narancssárga','Energikus, barátságos színvilág közösségi tartalmakhoz','#EA580C','#FB923C','#FFFFFF',1,'2025-01-06 13:15:15.632','2025-01-06 13:15:15.632'),('cm5l2h67r000157dqauy3vek6','Kék-zöld','teszt','#6DAEF0','#8DEBD1','#FFFFFF',1,'2025-01-06 13:17:51.926','2025-01-06 13:17:51.926'),('cm5lcso250002r51cthyb8wul','Meleg Narancssárga inverz','Energikus, barátságos színvilág közösségi tartalmakhoz','#FB923C','#EA580C','#FFFFFF',1,'2025-01-06 18:06:44.429','2025-01-06 18:06:44.429'),('cm5lgr4770000l9ongir14am0','Kék-Zöld Modern','Modern és friss színvilág, tökéletes digitális tartalmakhoz','#6DAEF0','#8DEBD1','#FFFFFF',1,'2025-01-06 19:57:30.499','2025-01-06 19:57:30.499'),('cm5lgr48v0001l9onfx038u21','Lila Elegáns','Elegáns, királyi megjelenés különleges alkalmakra','#6D28D9','#8B5CF6','#FFFFFF',1,'2025-01-06 19:57:30.559','2025-01-06 19:57:30.559'),('cm5lgr48y0002l9onifw1yma2','Sötétkék Professzionális','Komoly, megbízható megjelenés üzleti tartalmakhoz','#1E3A8A','#3B82F6','#FFFFFF',1,'2025-01-06 19:57:30.562','2025-01-06 19:57:30.562'),('cm5lgr48z0003l9onbt7ppa07','Meleg Narancssárga','Energikus, barátságos színvilág közösségi tartalmakhoz','#EA580C','#FB923C','#FFFFFF',1,'2025-01-06 19:57:30.564','2025-01-06 19:57:30.564');
/*!40000 ALTER TABLE `SavedTheme` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-08 12:29:39

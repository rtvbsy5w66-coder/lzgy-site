// __tests__/api/upload.test.ts
import { POST } from '@/app/api/upload/route';

// Mock NextRequest for testing
class MockNextRequest {
  constructor(url, options = {}) {
    this.url = url;
    this.method = options.method || 'GET';
    this.headers = new Map();
    this.body = options.body;
  }
  
  async formData() {
    return this.body;
  }
}

describe('Upload API', () => {
  describe('Basic File Upload Validation', () => {
    it('should reject request without file', async () => {
      const formData = new FormData();

      const response = await POST(
        new MockNextRequest('http://localhost:3000/api/upload', {
          method: 'POST',
          body: formData
        })
      );

      expect(response.status).toBe(400);
      const data = await response.json();
      expect(data.error).toBe('Nincs feltöltött fájl');
    });

    it('should accept valid image file', async () => {
      // Valid JPEG file content
      const content = new Uint8Array([
        0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46,
        0x49, 0x46, 0x00, 0x01, // JPEG header
        ...new Array(100).fill(0) // Image data
      ]);
      
      const fakeFile = new File([content], 'valid.jpg', { type: 'image/jpeg' });
      const formData = new FormData();
      formData.append('file', fakeFile);

      const response = await POST(
        new MockNextRequest('http://localhost:3000/api/upload', {
          method: 'POST',
          body: formData
        })
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.message).toBe('Kép sikeresen feltöltve');
      expect(data.type).toBe('image');
      expect(data.url).toMatch(/^\/uploads\/.*\.jpg$/);
    });

    it('should accept valid video file', async () => {
      const content = new Uint8Array([
        // MP4 header
        0x00, 0x00, 0x00, 0x20, 0x66, 0x74, 0x79, 0x70,
        ...new Array(100).fill(0) // Video data
      ]);
      
      const fakeFile = new File([content], 'valid.mp4', { type: 'video/mp4' });
      const formData = new FormData();
      formData.append('file', fakeFile);

      const response = await POST(
        new MockNextRequest('http://localhost:3000/api/upload', {
          method: 'POST',
          body: formData
        })
      );

      expect(response.status).toBe(200);
      const data = await response.json();
      expect(data.message).toBe('Videó sikeresen feltöltve');
      expect(data.type).toBe('video');
      expect(data.url).toMatch(/^\/uploads\/.*\.mp4$/);
    });

    it('should reject unsupported file types', async () => {
      const fakeFile = new File(['test content'], 'test.txt', { type: 'text/plain' });
      const formData = new FormData();
      formData.append('file', fakeFile);

      const response = await POST(
        new MockNextRequest('http://localhost:3000/api/upload', {
          method: 'POST',
          body: formData
        })
      );

      expect(response.status).toBe(400);
      const data = await response.json();
      expect(data.error).toBe('Csak kép vagy videó fájlok tölthetők fel');
    });
  });
});
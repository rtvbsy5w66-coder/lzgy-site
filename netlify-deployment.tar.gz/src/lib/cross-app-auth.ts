import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'

const CROSS_APP_SECRET = process.env.CROSS_APP_TOKEN!

export interface CrossAppTokenData {
  userId: string
  email: string
  role: string
  app: string
  iat?: number
  exp?: number
}

export function generateCrossAppToken(data: Omit<CrossAppTokenData, 'iat' | 'exp'>): string {
  return jwt.sign(data, CROSS_APP_SECRET, { expiresIn: '1h' })
}

export function verifyCrossAppToken(token: string): CrossAppTokenData | null {
  try {
    return jwt.verify(token, CROSS_APP_SECRET) as CrossAppTokenData
  } catch (error) {
    console.error('Cross-app token verification failed:', error)
    return null
  }
}

export function withCrossAppAuth(handler: (req: NextRequest, tokenData: CrossAppTokenData) => Promise<NextResponse>) {
  return async (req: NextRequest): Promise<NextResponse> => {
    const token = req.headers.get('Authorization')?.replace('Bearer ', '')

    if (!token) {
      return NextResponse.json({ error: 'Authorization header required' }, { status: 401 })
    }

    const tokenData = verifyCrossAppToken(token)
    if (!tokenData) {
      return NextResponse.json({ error: 'Invalid or expired token' }, { status: 401 })
    }

    try {
      return await handler(req, tokenData)
    } catch (error) {
      console.error('Cross-app API handler error:', error)
      return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
    }
  }
}

// Helper function to call AI app from main app
export async function callAIApp(endpoint: string, data: any, userToken?: string) {
  const aiAppUrl = process.env.AI_APP_URL || 'https://lovas-political-ai.vercel.app'
  
  const crossAppToken = generateCrossAppToken({
    userId: 'system',
    email: 'system@lovas-political.hu',
    role: 'system',
    app: 'main'
  })

  const response = await fetch(`${aiAppUrl}${endpoint}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${crossAppToken}`,
      'Content-Type': 'application/json',
      'X-User-Token': userToken || ''
    },
    body: JSON.stringify(data)
  })

  if (!response.ok) {
    throw new Error(`AI App call failed: ${response.statusText}`)
  }

  return response.json()
}
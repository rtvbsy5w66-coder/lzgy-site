import { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { PrismaClient } from "@prisma/client";
import { User_role } from "@prisma/client";
import { validateAuthEnvironment } from "./env-validation";

const prisma = new PrismaClient();

// Environment variables validálás
validateAuthEnvironment();

// NextAuth.js configuration
export const authOptions: NextAuthOptions = {
  // DEBUG KONFIGURÁCIÓ
  debug: process.env.NODE_ENV === "development" || process.env.NEXTAUTH_DEBUG === "true",
  
  logger: {
    error(code, metadata) {
      console.error(`[NextAuth Error] ${new Date().toISOString()} - ${code}:`, metadata);
    },
    warn(code) {
      console.warn(`[NextAuth Warning] ${new Date().toISOString()} - ${code}`);
    },
    debug(code, metadata) {
      if (process.env.NEXTAUTH_DEBUG === "true") {
        console.log(`[NextAuth Debug] ${new Date().toISOString()} - ${code}:`, metadata);
      }
    }
  },

  adapter: PrismaAdapter(prisma) as any,
  
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      authorization: {
        params: {
          scope: "openid email profile",
          prompt: "select_account",
          access_type: "offline"
        }
      }
    }),
  ],

  callbacks: {
    async signIn({ user, account, profile }) {
      console.log(`[SignIn Callback] Starting validation for: ${user.email}`);
      console.log(`[SignIn Callback] Provider: ${account?.provider}`);
      
      // Allow all Google sign-ins - admin restrictions will be handled in session callback
      if (account?.provider === 'google' && user.email) {
        console.log(`[SignIn Callback] APPROVED - Google login: ${user.email}`);
        return true;
      }

      console.log(`[SignIn Callback] REJECTED - Invalid provider or missing email`);
      return false;
    },

    async session({ session, user, trigger, newSession }) {
      console.log(`[Session Callback] Creating session for user:`, { 
        sessionEmail: session.user?.email,
        userId: user?.id,
        userRole: user?.role,
        trigger: trigger
      });
      
      if (session.user && user) {
        session.user.id = user.id;
        
        // Always fetch fresh user data from database to get latest displayName and phoneNumber
        if (trigger === 'update' || !(session.user as any).displayName) {
          try {
            const freshUser = await prisma.user.findUnique({
              where: { id: user.id },
              select: { 
                displayName: true, 
                phoneNumber: true, 
                role: true,
                name: true,
                email: true,
                image: true
              }
            });
            
            if (freshUser) {
              (session.user as any).displayName = freshUser.displayName;
              (session.user as any).phoneNumber = freshUser.phoneNumber;
              session.user.role = freshUser.role;
            }
          } catch (error) {
            console.error('[Session Callback] Error fetching fresh user data:', error);
          }
        } else {
          // Include existing displayName and phoneNumber in session
          (session.user as any).displayName = (user as any).displayName;
          (session.user as any).phoneNumber = (user as any).phoneNumber;
        }
        
        // Determine role: check if user is admin, otherwise assign USER role
        const adminEmails = process.env.ADMIN_EMAILS?.split(',').map(email => email.trim()) || [
          'admin@lovaszoltan.hu',
          'plscallmegiorgio@gmail.com'
        ];
        
        if (adminEmails.includes(session.user.email || '')) {
          session.user.role = User_role.ADMIN;
          console.log(`[Session Callback] Admin session created for: ${session.user.email}`);
        } else {
          session.user.role = user.role || User_role.USER;
          console.log(`[Session Callback] User session created for: ${session.user.email}`);
        }
      }
      
      return session;
    },

    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        
        // Determine role: check if user is admin, otherwise assign USER role  
        const adminEmails = process.env.ADMIN_EMAILS?.split(',').map(email => email.trim()) || [
          'admin@lovaszoltan.hu',
          'plscallmegiorgio@gmail.com'
        ];
        
        if (adminEmails.includes(token.email || '')) {
          token.role = User_role.ADMIN;
        } else {
          token.role = user.role || User_role.USER;
        }
        
        console.log(`[JWT Callback] JWT token updated for user: ${user.id} with role: ${token.role}`);
      }
      return token;
    }
  },

  session: {
    strategy: "database",
    maxAge: 24 * 60 * 60,
  },

  pages: {
    signIn: "/admin/login",
    error: "/admin/login",
  }
};

import NextAuth, { getServerSession } from "next-auth";

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };

// Helper function to get session on server side (App Router)
export const auth = () => getServerSession(authOptions);

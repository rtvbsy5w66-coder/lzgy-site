# 🔐 GitHub Actions Secrets - Aktuális Lista

**Generálva**: 2025-09-18  
**Projekt**: Lovas Political Site  
**CI/CD**: GitHub Actions Security Workflows

## 📋 KÖTELEZŐ SECRETS (Minimális működéshez)

### 🔐 **1. SNYK_TOKEN**
```
Név: SNYK_TOKEN
Típus: String
Cél: Dependency vulnerability scanning
Beszerzés: https://snyk.io → Account Settings → Auth Token
Példa: a1b2c3d4-e5f6-7890-abcd-ef1234567890
Státusz: ✅ KÖTELEZŐ
```

### 🗄️ **2. TEST_DATABASE_URL**  
```
Név: TEST_DATABASE_URL
Típus: String  
Cél: CI test database connection
Formátum: mysql://user:password@host:port/database
Példa: mysql://root:ci_test_pass@127.0.0.1:3306/lovas_test
Státusz: ✅ KÖTELEZŐ
```

### 🔐 **3. CI_ENCRYPTION_KEY**
```
Név: CI_ENCRYPTION_KEY
Típus: String
Cél: CI/CD sensitive data encryption
Generálás: openssl rand -base64 32
Példa: 1Sqy/oQgQubf1pGH1rf0QSsWoO5f8qSAUUj2RW/KGI8=
Státusz: ✅ KÖTELEZŐ
```

## 📨 NOTIFICATION SECRETS (Opcionális, de ajánlott)

### 📱 **4. SLACK_WEBHOOK_URL**
```
Név: SLACK_WEBHOOK_URL
Típus: String
Cél: Security alerts Slack channel-re
Beszerzés: Slack → Apps → Incoming Webhooks
Példa: https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX
Státusz: 🔶 OPCIONÁLIS (de erősen ajánlott)
```

### 🎮 **5. DISCORD_WEBHOOK**
```
Név: DISCORD_WEBHOOK
Típus: String
Cél: Security alerts Discord channel-re
Beszerzés: Discord → Server Settings → Integrations → Webhooks
Példa: https://discord.com/api/webhooks/123456789/abcdefghijklmnop
Státusz: 🔶 OPCIONÁLIS
```

## 🛡️ ADVANCED SECURITY SECRETS (Pro funkciókhoz)

### 🔍 **6. GITLEAKS_LICENSE**
```
Név: GITLEAKS_LICENSE
Típus: String
Cél: GitLeaks Pro features (enhanced secret detection)
Beszerzés: GitLeaks Pro subscription
Példa: ghs_1234567890abcdefghijklmnopqrstuvwxyz
Státusz: 🔶 OPCIONÁLIS (Pro feature)
```

### 📊 **7. SONARCLOUD_TOKEN**
```
Név: SONARCLOUD_TOKEN
Típus: String
Cél: Code quality és security analysis
Beszerzés: SonarCloud.io → My Account → Security
Példa: sqp_1234567890abcdefghijklmnopqrstuvwxyz123456
Státusz: 🔶 OPCIONÁLIS (Enhanced analysis)
```

## 🌐 PRODUCTION INTEGRATION SECRETS

### 📧 **8. NOTIFICATION_EMAIL**
```
Név: NOTIFICATION_EMAIL
Típus: String
Cél: Critical security alerts email címe
Formátum: email@domain.com
Példa: security-alerts@lovaszoltan.hu
Státusz: 🔶 OPCIONÁLIS
```

### 📱 **9. TEAMS_WEBHOOK**
```
Név: TEAMS_WEBHOOK
Típus: String
Cél: Microsoft Teams notifications
Beszerzés: Teams → Connectors → Incoming Webhook
Példa: https://outlook.office.com/webhook/a1b2c3d4.../IncomingWebhook/...
Státusz: 🔶 OPCIONÁLIS
```

## 🔧 DEVELOPMENT & TESTING SECRETS

### 🧪 **10. CI_GITHUB_TOKEN**
```
Név: CI_GITHUB_TOKEN
Típus: String
Cél: Enhanced GitHub API access (automatic - GitHub provides)
Automatikus: GitHub Actions automatically provides GITHUB_TOKEN
Példa: ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
Státusz: ✅ AUTOMATIKUS (GitHub által biztosított)
```

## 📋 SECRETS BEÁLLÍTÁSI ÚTMUTATÓ

### 🛠️ **Lépésről lépésre konfiguráció**

#### **1. GitHub Repository Secrets elérése**
```bash
1. Navigáljon: https://github.com/[USERNAME]/[REPOSITORY]
2. Kattintson: Settings tab
3. Kattintson: Secrets and variables → Actions
4. Kattintson: New repository secret
```

#### **2. Kötelező secrets beállítása**

**SNYK_TOKEN**:
```bash
1. Regisztráljon: https://snyk.io (ingyenes)
2. Bejelentkezés után: Account Settings
3. Kattintson: Auth Token tab
4. Copy token
5. GitHub-ban: Name: SNYK_TOKEN, Value: [másolt token]
```

**TEST_DATABASE_URL**:
```bash
1. CI környezet MySQL konfig:
   - Host: 127.0.0.1
   - Port: 3306  
   - User: root
   - Password: test_password
   - Database: lovas_test
2. GitHub-ban: Name: TEST_DATABASE_URL
   Value: mysql://root:test_password@127.0.0.1:3306/lovas_test
```

**CI_ENCRYPTION_KEY**:
```bash
1. Terminálban futtatás:
   openssl rand -base64 32
2. Kimenet másolása
3. GitHub-ban: Name: CI_ENCRYPTION_KEY, Value: [generált kulcs]
```

#### **3. Slack webhook beállítása (opcionális)**
```bash
1. Slack workspace → Apps
2. Keresés: "Incoming Webhooks"
3. Add to Slack
4. Choose channel: #security-alerts (vagy létrehoz új channel-t)
5. Copy webhook URL
6. GitHub-ban: Name: SLACK_WEBHOOK_URL, Value: [webhook URL]
```

## ✅ SECRETS ELLENŐRZŐ LISTA

### 🔴 **MINIMÁLIS KONFIGURÁCIÓ (Alapműködéshez)**
- [ ] `SNYK_TOKEN` - Vulnerability scanning
- [ ] `TEST_DATABASE_URL` - CI database  
- [ ] `CI_ENCRYPTION_KEY` - Secure encryption

### 🟡 **AJÁNLOTT KONFIGURÁCIÓ (Teljes funkcionalitáshoz)**
- [ ] `SNYK_TOKEN`
- [ ] `TEST_DATABASE_URL`
- [ ] `CI_ENCRYPTION_KEY`
- [ ] `SLACK_WEBHOOK_URL` - Real-time alerts

### 🟢 **TELJES KONFIGURÁCIÓ (Pro features)**
- [ ] Összes fenti + opcionális secrets
- [ ] `GITLEAKS_LICENSE` - Enhanced secret detection
- [ ] `DISCORD_WEBHOOK` - Multi-channel alerts
- [ ] `SONARCLOUD_TOKEN` - Advanced code analysis

## 🧪 SECRETS TESZTELÉSE

### **1. Secrets validáció workflow-val**
```bash
# Trigger manual workflow:
1. GitHub → Actions → "Security Audit & Testing"
2. "Run workflow" → Run workflow
3. Monitor logs for secret validation
```

### **2. Local secrets ellenőrzés**
```bash
# Repository klónozása után:
cd lovas-political-site
git status

# Ellenőrizni, hogy nincsenek .env fájlok commitolva:
find . -name ".env*" -not -name "*.example" -not -name "*.template"
# (Eredmény: üres legyen)
```

## 🚨 HIBAELHÁRÍTÁS

### **❌ "Secret not found" hiba**
```bash
Ellenőrizze:
1. Secret név pontosan egyezik (case-sensitive)
2. Secret value nem üres
3. Repository access permissions megfelelőek
4. Secret típusa "Repository secret" (nem Environment)
```

### **❌ Snyk authentication failed**
```bash
Ellenőrizze:
1. Snyk token érvényessége:
   curl -H "Authorization: token YOUR_TOKEN" https://snyk.io/api/v1/user/me
2. Token scope-ja megfelelő (read access minimum)
3. Token nem járt le
```

### **❌ Database connection failed**
```bash
Ellenőrizze:
1. MySQL service fut a CI-ben (workflow-ban beállítva)
2. Database URL formátum helyes
3. Credentials egyeznek a CI service konfiggal
```

## 📞 TÁMOGATÁS

### **🔗 Hasznos linkek**
- [GitHub Secrets Docs](https://docs.github.com/en/actions/security-guides/encrypted-secrets)
- [Snyk Token Setup](https://support.snyk.io/hc/en-us/articles/360004037537)
- [Slack Webhooks](https://api.slack.com/messaging/webhooks)

### **📧 További segítség**
Ha problémája van a secrets beállításával:
1. Ellenőrizze a workflow logs-okat részletes hibainformációért
2. Konzultáljon a `.github/SECURITY_WORKFLOW_DOCS.md` dokumentációval
3. Futassa le a `./security-test.sh` script-et lokálisan

---

## 🎯 KÖVETKEZŐ LÉPÉSEK

1. **Állítsa be a kötelező secrets-eket** (SNYK_TOKEN, TEST_DATABASE_URL, CI_ENCRYPTION_KEY)
2. **Konfigurálja a Slack webhook-ot** valós idejű alertekhez
3. **Trigger-elje az első workflow futtatást** teszteléshez
4. **Ellenőrizze a workflow eredményeket** a GitHub Actions tab-on

**A secrets beállítása után a biztonsági workflow-k teljes funkcionalitással működni fognak!** 🚀
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const post = await prisma.post.upsert({
    where: { slug: "elso-bejegyzes" },
    update: {},
    create: {
      title: "Első bejegyzés",
      slug: "elso-bejegyzes",
      content: "Ez az első bejegyzés tartalma.",
      excerpt: "Rövid kivonat az első bejegyzésből",
      status: "PUBLISHED",
    },
  });

  await Promise.all([
    prisma.theme.upsert({
      where: { id: "category-environment" },
      update: {},
      create: {
        id: "category-environment",
        name: "Környezetvédelem kategória",
        description: "Környezetvédelmi programok színvilága",
        fromColor: "#10b981",
        toColor: "#059669",
        textColor: "#FFFFFF",
        type: "CATEGORY",
        category: "Környezetvédelem",
        isActive: true,
      },
    }),
    prisma.theme.upsert({
      where: { id: "category-education" },
      update: {},
      create: {
        id: "category-education",
        name: "Oktatás kategória",
        description: "Oktatási programok színvilága",
        fromColor: "#3b82f6",
        toColor: "#2563eb",
        textColor: "#FFFFFF",
        type: "CATEGORY",
        category: "Oktatás",
        isActive: true,
      },
    }),
    prisma.theme.upsert({
      where: { id: "category-health" },
      update: {},
      create: {
        id: "category-health",
        name: "Egészségügy kategória",
        description: "Egészségügyi programok színvilága",
        fromColor: "#ec4899",
        toColor: "#be185d",
        textColor: "#FFFFFF",
        type: "CATEGORY",
        category: "Egészségügy",
        isActive: true,
      },
    }),
    prisma.theme.upsert({
      where: { id: "category-social" },
      update: {},
      create: {
        id: "category-social",
        name: "Szociális ügyek kategória",
        description: "Szociális programok színvilága",
        fromColor: "#67e8f9",
        toColor: "#06b6d4",
        textColor: "#FFFFFF",
        type: "CATEGORY",
        category: "Szociális ügyek",
        isActive: true,
      },
    }),
  ]);

  await prisma.theme.upsert({
    where: { id: "global-default" },
    update: {},
    create: {
      id: "global-default",
      name: "Alapértelmezett téma",
      description: "Az oldal alapértelmezett színvilága",
      fromColor: "#6DAEF0",
      toColor: "#8DEBD1",
      textColor: "#FFFFFF",
      type: "GLOBAL",
      isActive: true,
    },
  });

  // Add the existing test video as a slide in the database
  const slide = await prisma.slide.upsert({
    where: { id: "test-video-slide" },
    update: {},
    create: {
      id: "test-video-slide",
      type: "VIDEO",
      title: "Teszt Videó",
      subtitle: "Ez egy teszt videó slide",
      mediaUrl: "/uploads/escobarhun_cut.mp4",
      videoUrl: "/uploads/escobarhun_cut.mp4",
      videoType: "mp4",
      autoPlay: true,
      isLoop: true,
      isMuted: true,
      isActive: true,
      order: 1,
      gradientFrom: "",
      gradientTo: "",
      ctaText: "",
      ctaLink: "",
    },
  });

  // Add gradient text slides
  const gradientSlides = await Promise.all([
    prisma.slide.upsert({
      where: { id: "gradient-slide-1" },
      update: {},
      create: {
        id: "gradient-slide-1",
        type: "GRADIENT",
        title: "Mindenki Magyarországa",
        subtitle: "Egy tisztességes, demokratikus és modern ország építéséért dolgozunk minden magyar állampolgárral együtt.",
        gradientFrom: "#667eea",
        gradientTo: "#764ba2",
        isActive: true,
        order: 2,
        ctaText: "Programunk",
        ctaLink: "/program",
        mediaUrl: null,
        videoUrl: null,
        videoType: null,
        autoPlay: null,
        isLoop: null,
        isMuted: null,
      },
    }),
    prisma.slide.upsert({
      where: { id: "gradient-slide-2" },
      update: {},
      create: {
        id: "gradient-slide-2",
        type: "GRADIENT",
        title: "Változásra van szükség",
        subtitle: "Elég volt a korrupcióból és a politikai színjátékból. Itt az ideje az átlátható, tisztességes politizálásnak.",
        gradientFrom: "#f093fb",
        gradientTo: "#f5576c",
        isActive: true,
        order: 3,
        ctaText: "Rólam",
        ctaLink: "/rolam",
        mediaUrl: null,
        videoUrl: null,
        videoType: null,
        autoPlay: null,
        isLoop: null,
        isMuted: null,
      },
    }),
    prisma.slide.upsert({
      where: { id: "gradient-slide-3" },
      update: {},
      create: {
        id: "gradient-slide-3",
        type: "GRADIENT",
        title: "Közösség és Összefogás",
        subtitle: "Csak együtt, közösen tudunk változást hozni. Csatlakozz hozzánk, és építsük fel együtt a jövőt!",
        gradientFrom: "#4facfe",
        gradientTo: "#00f2fe",
        isActive: true,
        order: 4,
        ctaText: "Kapcsolat",
        ctaLink: "/kapcsolat",
        mediaUrl: null,
        videoUrl: null,
        videoType: null,
        autoPlay: null,
        isLoop: null,
        isMuted: null,
      },
    }),
    prisma.slide.upsert({
      where: { id: "gradient-slide-4" },
      update: {},
      create: {
        id: "gradient-slide-4",
        type: "GRADIENT",
        title: "Fenntartható Jövő",
        subtitle: "Környezetvédelem, megújuló energia és fenntartható fejlődés - ezek a jövő alapkövei.",
        gradientFrom: "#43e97b",
        gradientTo: "#38f9d7",
        isActive: true,
        order: 5,
        ctaText: "Hírek",
        ctaLink: "/hirek",
        mediaUrl: null,
        videoUrl: null,
        videoType: null,
        autoPlay: null,
        isLoop: null,
        isMuted: null,
      },
    }),
  ]);

  // Add a test event
  const testEvent = await prisma.event.upsert({
    where: { id: "test-event-1" },
    update: {},
    create: {
      id: "test-event-1",
      title: "Városi Fórum - Beszélgetés a jövőről",
      description: "Csatlakozzon hozzánk egy interaktív beszélgetésre a város jövőjéről, ahol meghallgatjuk az Ön véleményét és ötleteit a helyi fejlesztésekkel kapcsolatban.",
      location: "Városháza díszterme, Budapest",
      startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 1 week from now
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000 + 2 * 60 * 60 * 1000), // 2 hours later
      status: "UPCOMING",
      maxAttendees: 50,
    },
  });

  console.log({ post, slide, gradientSlides, testEvent });
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });

import{T as o}from"./theme-toggle-Yo4_otZi.js";import"./iframe-CH0y9Ln_.js";import"./preload-helper-PPVm8Dsz.js";import"./createLucideIcon-DBITYvIf.js";const m={title:"Theme/ThemeToggle",component:o,parameters:{layout:"centered"},tags:["autodocs"]},e={},r={parameters:{backgrounds:{default:"light"}}},a={parameters:{backgrounds:{default:"dark"}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:"{}",...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  parameters: {
    backgrounds: {
      default: 'light'
    }
  }
}`,...r.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  parameters: {
    backgrounds: {
      default: 'dark'
    }
  }
}`,...a.parameters?.docs?.source}}};const n=["Default","LightMode","DarkMode"];export{a as DarkMode,e as Default,r as LightMode,n as __namedExportsOrder,m as default};

import{e as p,j as e}from"./iframe-CH0y9Ln_.js";import{L as a}from"./link-CvR36xeY.js";import{T as d}from"./theme-toggle-Yo4_otZi.js";import{c as i}from"./createLucideIcon-DBITYvIf.js";import"./preload-helper-PPVm8Dsz.js";/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=i("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=i("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),u=()=>{const[l,m]=p.useState(!1),c=[{href:"/",text:"Kezdőlap"},{href:"/rolam",text:"Rólam"},{href:"/program",text:"Program"},{href:"/esemenyek",text:"Események"},{href:"/hirek",text:"Hírek"}];return e.jsx("nav",{className:"w-full fixed top-0 bg-white/70 backdrop-blur-md z-50 dark:bg-black/70",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4",children:[e.jsxs("div",{className:"flex justify-between h-20",children:[e.jsx(a,{href:"/",className:"flex items-center text-3xl font-bold bg-gradient-to-r from-[#6DAEF0] to-[#8DEBD1] bg-clip-text text-transparent",children:"Lovas Zoltán György"}),e.jsxs("div",{className:"md:flex hidden items-center space-x-8",children:[c.map(r=>e.jsx(a,{href:r.href,className:"text-gray-700 hover:text-[#6DAEF0] dark:text-gray-200 dark:hover:text-[#8DEBD1] transition-colors duration-300",children:r.text},r.href)),e.jsx(a,{href:"/kapcsolat",className:"px-6 py-2 bg-gradient-to-r from-[#6DAEF0] to-[#8DEBD1] text-white rounded-full hover:shadow-lg transition-all duration-300",children:"Kapcsolat"}),e.jsx(d,{})]}),e.jsxs("div",{className:"md:hidden flex items-center space-x-4",children:[e.jsx(d,{}),e.jsx("button",{className:"text-gray-700 dark:text-gray-200",onClick:()=>m(!l),children:l?e.jsx(h,{}):e.jsx(x,{})})]})]}),l&&e.jsx("div",{className:"md:hidden bg-white/95 dark:bg-black/95 backdrop-blur-md",children:e.jsxs("div",{className:"px-2 pt-2 pb-3 space-y-1",children:[c.map(r=>e.jsx(a,{href:r.href,className:"block px-3 py-2 text-gray-700 hover:text-[#6DAEF0] dark:text-gray-200 dark:hover:text-[#8DEBD1] transition-colors duration-300",children:r.text},`mobile-${r.href}`)),e.jsx(a,{href:"/kapcsolat",className:"block px-3 py-2 text-[#6DAEF0] dark:text-[#8DEBD1] font-semibold",children:"Kapcsolat"})]})})]})})},j={title:"Components/Navigation",component:u,parameters:{layout:"fullscreen"},tags:["autodocs"]},t={},s={parameters:{backgrounds:{default:"dark"}}},o={parameters:{viewport:{defaultViewport:"mobile1"}}},n={parameters:{viewport:{defaultViewport:"tablet"}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:"{}",...t.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  parameters: {
    backgrounds: {
      default: 'dark'
    }
  }
}`,...s.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...o.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'tablet'
    }
  }
}`,...n.parameters?.docs?.source}}};const v=["Default","DarkTheme","Mobile","Tablet"];export{s as DarkTheme,t as Default,o as Mobile,n as Tablet,v as __namedExportsOrder,j as default};

// src/app/metadata.ts
export const metadata = {
  title: "Lovas Zoltán György",
  description: "Modern megoldások, átlátható kormányzás, fenntartható fejlődés",
};

import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";
import { User_role } from "@prisma/client";

console.log(`[Middleware] Loaded at ${new Date().toISOString()}`);

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token;
    const { pathname } = req.nextUrl;

    console.log(`[Middleware] Request: ${pathname}`);
    console.log(`[Middleware] Token present: ${!!token}`);
    console.log(`[Middleware] Token role: ${token?.role}`);
    console.log(`[Middleware] Token email: ${token?.email}`);

    // Admin route protection
    if (pathname.startsWith('/admin')) {
      if (pathname === '/admin/login') {
        if (token?.role === User_role.ADMIN) {
          console.log(`[Middleware] Already authenticated, redirecting to /admin`);
          return NextResponse.redirect(new URL('/admin', req.url));
        }
        console.log(`[Middleware] Access granted to login page`);
        return NextResponse.next();
      }

      if (!token || token.role !== User_role.ADMIN) {
        console.log(`[Middleware] Access denied to ${pathname} - redirecting to login`);
        const loginUrl = new URL('/admin/login', req.url);
        loginUrl.searchParams.set('callbackUrl', pathname);
        return NextResponse.redirect(loginUrl);
      }

      console.log(`[Middleware] Admin access granted: ${token.email} -> ${pathname}`);
    }

    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        const { pathname } = req.nextUrl;
        
        // Admin routes require authentication
        if (pathname.startsWith('/admin') && pathname !== '/admin/login') {
          return token?.role === User_role.ADMIN;
        }
        
        // All other routes are accessible
        return true;
      },
    },
  }
);

export const config = {
  matcher: [
    '/admin/:path*',
    '/((?!api|_next/static|_next/image|favicon.ico|uploads).*)',
  ],
};
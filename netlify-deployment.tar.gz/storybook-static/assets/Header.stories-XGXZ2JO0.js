import{H as a}from"./Header-BXgvpruN.js";import"./iframe-CH0y9Ln_.js";import"./preload-helper-PPVm8Dsz.js";import"./Button-V9nAt19G.js";const{fn:r}=__STORYBOOK_MODULE_TEST__,m={title:"Example/Header",component:a,tags:["autodocs"],parameters:{layout:"fullscreen"},args:{onLogin:r(),onLogout:r(),onCreateAccount:r()}},e={args:{user:{name:"Jane Doe"}}},o={};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    user: {
      name: 'Jane Doe'
    }
  }
}`,...e.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:"{}",...o.parameters?.docs?.source}}};const p=["LoggedIn","LoggedOut"];export{e as LoggedIn,o as LoggedOut,p as __namedExportsOrder,m as default};

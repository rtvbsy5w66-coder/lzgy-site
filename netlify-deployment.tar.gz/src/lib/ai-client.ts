// AI Service Client for cross-app communication

const AI_APP_URL = process.env.AI_APP_URL || 'https://lovas-political-5mx3a4do2-giorgio-cavalieres-projects.vercel.app';
const INTERNAL_API_KEY = process.env.INTERNAL_API_KEY || 'lovas-ai-secure-key-2024-production';

export interface AIAnalysisResult {
  success: boolean;
  analysis?: {
    category: string;
    urgency: 'low' | 'medium' | 'high' | 'emergency';
    sentiment: 'positive' | 'neutral' | 'negative';
    keywords: string[];
    suggestedActions: string[];
    confidence: number;
  };
  model?: string;
  timestamp?: string;
  source?: string;
  error?: string;
}

export interface AIServiceStatus {
  success: boolean;
  status?: {
    service: string;
    model: string;
    version: string;
    ollama_url: string;
    last_check: string;
    capabilities: string[];
    stats: {
      total_requests: number;
      success_rate: string;
      average_response_time: string;
    };
  };
  timestamp?: string;
  authenticated?: boolean;
  source?: string;
  error?: string;
}

class AIServiceClient {
  private baseUrl: string;
  private apiKey: string;

  constructor(baseUrl: string = AI_APP_URL, apiKey: string = INTERNAL_API_KEY) {
    this.baseUrl = baseUrl;
    this.apiKey = apiKey;
  }

  private async makeRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.baseUrl}/api/ai${endpoint}`;
    
    const headers = {
      'Content-Type': 'application/json',
      'X-API-Key': this.apiKey,
      'User-Agent': 'lovas-political-main/1.0',
      ...options.headers,
    };

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      throw new Error(`AI Service error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async analyzeText(text: string, type: string = 'citizen-report'): Promise<AIAnalysisResult> {
    try {
      return await this.makeRequest<AIAnalysisResult>('/analyze', {
        method: 'POST',
        body: JSON.stringify({ text, type }),
      });
    } catch (error) {
      console.error('AI Analysis failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Analysis failed'
      };
    }
  }

  async getServiceStatus(): Promise<AIServiceStatus> {
    try {
      return await this.makeRequest<AIServiceStatus>('/status');
    } catch (error) {
      console.error('AI Service status check failed:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Status check failed'
      };
    }
  }

  async analyzeCitizenReport(reportText: string): Promise<AIAnalysisResult> {
    return this.analyzeText(reportText, 'citizen-report');
  }

  async analyzePostContent(postContent: string): Promise<AIAnalysisResult> {
    return this.analyzeText(postContent, 'post-content');
  }

  async analyzeEvent(eventDescription: string): Promise<AIAnalysisResult> {
    return this.analyzeText(eventDescription, 'event-description');
  }
}

// Singleton instance
export const aiClient = new AIServiceClient();

// Helper functions for common operations
export async function analyzeTextWithAI(text: string, type?: string): Promise<AIAnalysisResult> {
  return aiClient.analyzeText(text, type);
}

export async function getAIServiceHealth(): Promise<boolean> {
  const status = await aiClient.getServiceStatus();
  return status.success && status.status?.service === 'online';
}

export async function analyzeCitizenReport(reportText: string): Promise<AIAnalysisResult> {
  return aiClient.analyzeCitizenReport(reportText);
}

// Admin functions
export async function getAIServiceInfo(): Promise<AIServiceStatus> {
  return aiClient.getServiceStatus();
}

export default aiClient;
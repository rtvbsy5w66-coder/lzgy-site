import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Simple test response for now
    return NextResponse.json({
      success: true,
      message: 'Test bejelentés endpoint működik',
      data: { id: 'test-123', ...body }
    }, { status: 201 });

  } catch (error) {
    console.error('Create report error:', error);
    
    return NextResponse.json(
      { error: 'Hiba történt a bejelentés mentése során' },
      { status: 500 }
    );
  }
}
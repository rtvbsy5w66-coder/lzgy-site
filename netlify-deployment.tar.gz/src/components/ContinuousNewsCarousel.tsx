"use client";

import React, { useState, useEffect, useRef } from "react";
import { ArrowRight, Calendar, Pause, Play } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { useThemeColors } from "@/context/ThemeContext";

interface Post {
  id: string;
  title: string;
  content: string;
  excerpt?: string;
  category?: string;
  imageUrl?: string;
  status: "DRAFT" | "PUBLISHED";
  createdAt: string;
  updatedAt: string;
  newsCategory?: {
    id: string;
    name: string;
    color: string;
  };
}

interface ContinuousNewsCarouselProps {
  posts: Post[];
  truncateContent: (content: string, maxLength?: number) => string;
  autoScroll?: boolean;
  scrollSpeed?: number; // pixels per second
}

export const ContinuousNewsCarousel: React.FC<ContinuousNewsCarouselProps> = ({
  posts,
  truncateContent,
  autoScroll = true,
  scrollSpeed = 50
}) => {
  const [isScrolling, setIsScrolling] = useState(autoScroll);
  const [translateX, setTranslateX] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const carouselRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number>();
  const themeColors = useThemeColors('NEWS');
  
  // Duplicate posts for infinite scroll effect
  const duplicatedPosts = [...posts, ...posts, ...posts];
  const isDarkMode = themeColors.mode === 'dark';

  // Responsive card width calculation
  const getCardWidth = () => {
    if (typeof window === 'undefined') return 320;
    
    if (window.innerWidth >= 1280) return 320; // xl: 4 cards
    if (window.innerWidth >= 1024) return 340; // lg: 3 cards  
    if (window.innerWidth >= 768) return 380;  // md: 2 cards
    return 300; // sm: 1 card with margins
  };

  const getVisibleCards = () => {
    if (typeof window === 'undefined') return 4;
    
    if (window.innerWidth >= 1280) return 4; // xl: 4 cards
    if (window.innerWidth >= 1024) return 3; // lg: 3 cards
    if (window.innerWidth >= 768) return 2;  // md: 2 cards
    return 1; // sm: 1 card
  };

  // Continuous scrolling animation
  useEffect(() => {
    if (!isScrolling || isPaused) return;

    const animate = () => {
      setTranslateX(prev => {
        const cardWidth = getCardWidth() + 24; // card width + gap
        const resetPoint = -(posts.length * cardWidth);
        
        const newValue = prev - (scrollSpeed / 60); // 60fps
        
        // Reset when we've scrolled through one full set of posts
        if (newValue <= resetPoint) {
          return 0;
        }
        
        return newValue;
      });
      
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isScrolling, isPaused, posts.length, scrollSpeed]);

  // Pause on hover
  const handleMouseEnter = () => setIsPaused(true);
  const handleMouseLeave = () => setIsPaused(false);

  // Toggle auto-scroll
  const toggleAutoScroll = () => {
    setIsScrolling(!isScrolling);
  };

  const NewsCard: React.FC<{ post: Post; index: number }> = ({ post, index }) => {
    const categoryColor = post.newsCategory?.color || "#6b7280";
    
    return (
      <div
        className="flex-shrink-0 w-80 h-96 group"
        style={{ width: `${getCardWidth()}px` }}
      >
        <Link
          href={`/hirek/${post.id}`}
          className="block h-full rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-t-4 cursor-pointer"
          style={{
            background: post.newsCategory 
              ? (isDarkMode 
                  ? `linear-gradient(135deg, ${categoryColor}15 0%, ${categoryColor}25 100%)`
                  : `linear-gradient(135deg, ${categoryColor}08 0%, ${categoryColor}15 100%)`)
              : (isDarkMode ? '#1f2937' : '#ffffff'),
            borderTopColor: categoryColor,
            boxShadow: `0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 10px 15px -3px ${categoryColor}20`
          }}
        >
          {/* Image Section or Category Background */}
          {post.imageUrl ? (
            <div className="relative h-48 overflow-hidden">
              <Image
                src={post.imageUrl}
                alt={post.title}
                fill
                sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 25vw"
                className="object-cover transition-transform duration-500 group-hover:scale-110"
                priority={index < 4}
              />
              
              {/* Category Badge Overlay for Images */}
              {post.newsCategory && (
                <div className="absolute top-3 right-3">
                  <span 
                    className="px-3 py-1 rounded-full text-xs font-semibold text-white backdrop-blur-sm"
                    style={{
                      backgroundColor: `${categoryColor}e6`,
                      border: `1px solid ${categoryColor}`
                    }}
                  >
                    {post.newsCategory.name}
                  </span>
                </div>
              )}
            </div>
          ) : (
            /* Category Background for Image-less Cards */
            <div 
              className="relative h-48 overflow-hidden flex items-center justify-center"
              style={{
                background: `linear-gradient(135deg, ${categoryColor}20 0%, ${categoryColor}40 50%, ${categoryColor}60 100%)`,
              }}
            >
              {/* Decorative Pattern */}
              <div 
                className="absolute inset-0 opacity-10"
                style={{
                  backgroundImage: `radial-gradient(circle at 20% 20%, ${categoryColor} 2px, transparent 2px), 
                                   radial-gradient(circle at 80% 80%, ${categoryColor} 1px, transparent 1px)`,
                  backgroundSize: '30px 30px, 20px 20px'
                }}
              />
              
              {/* Category Icon/Name Display */}
              <div className="relative z-10 text-center">
                {post.newsCategory && (
                  <>
                    {/* Large Category Icon */}
                    <div 
                      className="w-16 h-16 rounded-full mb-4 mx-auto flex items-center justify-center"
                      style={{
                        backgroundColor: `${categoryColor}30`,
                        border: `2px solid ${categoryColor}60`
                      }}
                    >
                      <span 
                        className="text-2xl font-bold"
                        style={{ color: categoryColor }}
                      >
                        {post.newsCategory.name.charAt(0)}
                      </span>
                    </div>
                    
                    {/* Category Name */}
                    <h4 
                      className="text-lg font-bold mb-2"
                      style={{ color: categoryColor }}
                    >
                      {post.newsCategory.name}
                    </h4>
                    
                    {/* Decorative subtitle */}
                    <p 
                      className="text-sm opacity-80"
                      style={{ color: categoryColor }}
                    >
                      Friss hírek
                    </p>
                  </>
                )}
                
                {/* Fallback if no category */}
                {!post.newsCategory && (
                  <div>
                    <div 
                      className="w-16 h-16 rounded-full mb-4 mx-auto flex items-center justify-center bg-gray-200"
                    >
                      <span className="text-2xl font-bold text-gray-500">H</span>
                    </div>
                    <h4 className="text-lg font-bold text-gray-600">Hírek</h4>
                  </div>
                )}
              </div>
              
              {/* Subtle overlay for depth */}
              <div 
                className="absolute inset-0 opacity-5"
                style={{
                  background: `linear-gradient(45deg, transparent 30%, ${categoryColor} 50%, transparent 70%)`
                }}
              />
            </div>
          )}

          {/* Content Section */}
          <div className="p-5 flex flex-col h-48 justify-between">
            {/* Header */}
            <div>
              <div className="flex items-center justify-between text-xs mb-3">
                <div 
                  className="flex items-center"
                  style={{ color: categoryColor }}
                >
                  <Calendar className="h-3 w-3 mr-1" />
                  <time dateTime={post.createdAt}>
                    {new Date(post.createdAt).toLocaleDateString("hu-HU", {
                      month: "short",
                      day: "numeric",
                    })}
                  </time>
                </div>
                
              </div>

              {/* Title */}
              <h3 
                className="text-lg font-bold mb-2 line-clamp-2 group-hover:text-opacity-80 transition-colors"
                style={{ 
                  color: isDarkMode ? "#ffffff" : "#111111"
                }}
              >
                {post.title}
              </h3>

              {/* Excerpt */}
              <p 
                className="text-sm leading-relaxed line-clamp-3 mb-3"
                style={{ 
                  color: isDarkMode ? "#ffffff" : "#6b7280",
                  opacity: isDarkMode ? 0.9 : 1
                }}
              >
                {post.excerpt || truncateContent(post.content, 120)}
              </p>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between">
              <div
                className="inline-flex items-center text-sm font-medium transition-all duration-200 group/link hover:gap-2"
                style={{ color: categoryColor }}
              >
                <span>Tovább</span>
                <ArrowRight className="ml-1 h-4 w-4 transition-transform duration-200 group-hover/link:translate-x-1" />
              </div>
              
              {/* Accent dot */}
              <div 
                className="w-2 h-2 rounded-full opacity-60"
                style={{ backgroundColor: categoryColor }}
              />
            </div>
          </div>
        </Link>
      </div>
    );
  };

  if (posts.length === 0) return null;

  return (
    <div className="relative w-full">
      {/* Header with minimal controls - centered with max-w */}
      <div className="max-w-7xl mx-auto px-4 mb-8">
        <div className="flex items-center justify-between">
          <h2 
            className="text-3xl font-bold"
            style={{ color: isDarkMode ? "#ffffff" : "#111111" }}
          >
            Legfrissebb Hírek
          </h2>

          {/* Simple auto-scroll toggle - minimal design */}
          <button
            onClick={toggleAutoScroll}
            className="flex items-center space-x-2 px-3 py-2 rounded-full transition-all duration-300 hover:scale-105 opacity-60 hover:opacity-100"
            style={{
              backgroundColor: `${themeColors.gradientFrom}10`,
              border: `1px solid ${themeColors.gradientFrom}20`
            }}
            title={isScrolling ? 'Automatikus görgetés szüneteltetése' : 'Automatikus görgetés indítása'}
          >
            {isScrolling ? (
              <Pause className="h-4 w-4" style={{ color: themeColors.gradientFrom }} />
            ) : (
              <Play className="h-4 w-4" style={{ color: themeColors.gradientFrom }} />
            )}
          </button>
        </div>
      </div>

      {/* Carousel Container - full width edge-to-edge */}
      <div className="relative overflow-hidden w-full">
        {/* Gradient overlays for smooth edges */}
        <div 
          className="absolute left-0 top-0 w-8 h-full z-10 pointer-events-none"
          style={{
            background: `linear-gradient(to right, ${themeColors.bg}, transparent)`
          }}
        />
        <div 
          className="absolute right-0 top-0 w-8 h-full z-10 pointer-events-none"
          style={{
            background: `linear-gradient(to left, ${themeColors.bg}, transparent)`
          }}
        />

        {/* Cards Container */}
        <div
          ref={carouselRef}
          className="flex gap-6 py-4"
          style={{
            transform: `translateX(${translateX}px)`,
            width: 'max-content'
          }}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          {duplicatedPosts.map((post, index) => (
            <NewsCard 
              key={`${post.id}-${Math.floor(index / posts.length)}`} 
              post={post} 
              index={index}
            />
          ))}
        </div>
      </div>

      {/* Bottom info - centered with max-w */}
      <div className="max-w-7xl mx-auto px-4 mt-8">
        <div className="flex items-center justify-center">
          <Link
            href="/hirek"
            className="inline-flex items-center px-6 py-3 text-sm font-medium rounded-full transition-all duration-300 hover:scale-105 hover:shadow-lg"
            style={{ 
              background: themeColors.gradient,
              color: themeColors.accent,
              border: `1px solid ${themeColors.gradientFrom}40`
            }}
          >
            Minden hír megtekintése
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ContinuousNewsCarousel;
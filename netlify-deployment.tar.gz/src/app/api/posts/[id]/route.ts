// src/app/api/posts/[id]/route.ts
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { generateSlug } from "@/utils/posts";
import { NEWS_CATEGORY_COLORS } from "@/constants/news-categories";

// Mock fallback data for individual posts - ALL POSTS FOR COMPREHENSIVE TESTING
const mockPosts = [
  // V. kerület - Képviselői hírek
  {
    id: "mock-v1",
    title: "Új játszótér épült a Kossuth téren - V. kerületi fejlesztés",
    slug: "uj-jatszotez-epult-a-kossuth-teren",
    content: "Az V. kerületi önkormányzat támogatásával egy modern, akadálymentes játszótér épült a Kossuth téren. A fejlesztés 15 millió forintba került és teljes mértékben megújította a területet. Az új játszótér tartalmaz mászókát, hintákat, homokozót és pihenőpadokat is.",
    excerpt: "Modern, akadálymentes játszótér épült az V. kerületben, 15 millió forint értékben.",
    status: "PUBLISHED",
    category: "V. kerület",
    imageUrl: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?fit=crop&crop=center",
    createdAt: "2025-03-15T10:00:00Z",
    updatedAt: "2025-03-15T10:00:00Z"
  },
  {
    id: "mock-v2",
    title: "Bike-sharing rendszer bővítése az V. kerületben",
    slug: "bike-sharing-rendszer-bovitese-v-keruletben",
    content: "A kerületi képviselői munkám eredményeként 5 új MOL Bubi állomás létesül az V. kerületben. A fejlesztés javítja a közlekedési lehetőségeket és környezetbarát alternatívát kínál a lakóknak.",
    excerpt: "5 új MOL Bubi állomás létesül az V. kerületben a képviselői munka eredményeként.",
    status: "PUBLISHED",
    category: "V. kerület",
    imageUrl: null,
    createdAt: "2025-03-10T14:30:00Z",
    updatedAt: "2025-03-10T14:30:00Z"
  },
  {
    id: "mock-v3",
    title: "Közterület-fejlesztés a Veres Pálné utcában",
    slug: "kozterulet-fejlesztes-veres-palne-utcaban",
    content: "Az V. kerületi lakók kérésére kezdeményeztem a Veres Pálné utca járdáinak felújítását. A munkálatok március végén kezdődnek és várhatóan 2 hétig tartanak. A fejlesztés során új burkolatot kapnak a járdák és javítjuk a vízelvezetést is.",
    excerpt: "Járdafelújítás kezdődik a Veres Pálné utcában az V. kerületi lakók kérésére.",
    status: "PUBLISHED",
    category: "V. kerület",
    imageUrl: null,
    createdAt: "2025-03-08T09:15:00Z",
    updatedAt: "2025-03-08T09:15:00Z"
  },
  {
    id: "mock-v4",
    title: "Fogadóóra eredményei - V. kerületi ügyek",
    slug: "fogadoora-eredmenyei-v-keruleti-ugyek",
    content: "A március 5-i fogadóórán 15 V. kerületi lakó kereste fel irodámat különböző ügyekkel. A legfontosabb témák: közvilágítás javítása a Falk Miksa utcában, parkolási problémák megoldása és a köztisztaság javítása. Minden ügyben konkrét lépéseket tettem.",
    excerpt: "15 lakó kereste fel a képviselői irodát a március 5-i fogadóórán.",
    status: "PUBLISHED",
    category: "V. kerület",
    imageUrl: null,
    createdAt: "2025-03-06T16:00:00Z",
    updatedAt: "2025-03-06T16:00:00Z"
  },
  {
    id: "mock-v5",
    title: "Zöldterület-fejlesztés a Honvéd utcában",
    slug: "zoldterulet-fejlesztes-honved-utcaban",
    content: "Az V. kerületi lakosság igényeire reagálva új zöld területet alakítunk ki a Honvéd utca és a Zrínyi utca sarkán. Az új parkocska virágágyásokat, padokat és néhány fát is kap. A munkálatok áprilisban kezdődnek.",
    excerpt: "Új parkocska létesül a Honvéd utca és Zrínyi utca sarkán az V. kerületben.",
    status: "PUBLISHED",
    category: "V. kerület",
    imageUrl: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?fit=crop&crop=center",
    createdAt: "2025-03-01T11:00:00Z",
    updatedAt: "2025-03-01T11:00:00Z"
  },

  // Általános hírek (5 hír, 70% képpel)
  {
    id: "mock-1",
    title: "Új környezetvédelmi kezdeményezés országos szinten",
    slug: "uj-kornyezetvedeli-kezdemenyezes-orszagos-szinten",
    content: "Országos környezetvédelmi programot indítunk, amely a zöld energia használatát és a hulladékcsökkentést helyezi előtérbe. A program keretében napelemes rendszereket telepítünk közintézményekbe és támogatást nyújtunk a családi házak tulajdonosainak is.",
    excerpt: "Új országos környezetvédelmi program a zöld energia használatáért és hulladékcsökkentésért.",
    status: "PUBLISHED",
    category: "Hírek",
    imageUrl: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?fit=crop&crop=center",
    createdAt: "2025-09-20T10:00:00Z",
    updatedAt: "2025-09-20T10:00:00Z"
  },
  {
    id: "mock-2",
    title: "Digitalizációs program az oktatásban",
    slug: "digitalizacios-program-az-oktatasban",
    content: "Modern digitális eszközökkel és módszerekkel forradalmasítjuk meg az oktatást. Minden iskola kap tableteket, interaktív táblákat és gyorsabb internetet. A pedagógusok számára ingyenes továbbképzéseket szervezünk.",
    excerpt: "Digitális forradalom az oktatásban: tabletek, interaktív táblák és továbbképzések.",
    status: "PUBLISHED",
    category: "Hírek",
    imageUrl: null,
    createdAt: "2025-09-18T14:30:00Z",
    updatedAt: "2025-09-18T14:30:00Z"
  },
  {
    id: "mock-3",
    title: "Egészségügyi várólisták felszámolása",
    slug: "egeszsegugyi-varolistak-felszamolasa",
    content: "Konkrét intézkedésekkel csökkentjük az egészségügyi várólistákat. Több orvost alkalmazunk, hosszabb rendelési időket biztosítunk és modern diagnosztikai eszközöket vásárolunk. Cél: 50%-os várólistaszokás egy év alatt.",
    excerpt: "50%-kal csökkentjük az egészségügyi várólistákat egy év alatt konkrét intézkedésekkel.",
    status: "PUBLISHED",
    category: "Hírek",
    imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?fit=crop&crop=center",
    createdAt: "2025-09-15T09:15:00Z",
    updatedAt: "2025-09-15T09:15:00Z"
  },
  {
    id: "mock-h4",
    title: "Nyugdíjprémium emelés 2024-ben",
    slug: "nyugdijpremium-emeles-2024-ben",
    content: "Jelentős nyugdíjemelést hajtunk végre 2024-ben. Minden nyugdíjas legalább 10%-os emelést kap, a legalacsonyabb nyugdíjak esetében akár 25%-os növekedés is lehetséges. A változások január 1-től lépnek életbe és visszamenőleg is érvényesek.",
    excerpt: "10-25%-os nyugdíjemelés 2024-ben - január 1-től visszamenőleg is érvényes.",
    status: "PUBLISHED",
    category: "Hírek",
    imageUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?fit=crop&crop=center",
    createdAt: "2025-09-12T11:30:00Z",
    updatedAt: "2025-09-12T11:30:00Z"
  },
  {
    id: "mock-h5",
    title: "Új munkahelyek a technológiai szektorban",
    slug: "uj-munkahelyek-technologiai-szektorban",
    content: "5000 új munkahely létesül a technológiai szektorban a következő két évben. Nemzetközi nagyvállalatok telepítik le magyarországi fejlesztőközpontjaikat. Átlagfizetés: 800.000 - 1.2 millió forint havonta. Jelentkezési lehetőségek már elérhetők.",
    excerpt: "5000 új tech munkahely 2 év alatt, 800K-1.2M Ft fizetéssel - jelentkezés már elérhető.",
    status: "PUBLISHED",
    category: "Hírek",
    imageUrl: null,
    createdAt: "2025-09-08T16:45:00Z",
    updatedAt: "2025-09-08T16:45:00Z"
  },

  // Események (5 hír, 80% képpel)
  {
    id: "mock-e1",
    title: "Közösségi találkozó a Kossuth téren",
    slug: "kozossegi-talalkozo-a-kossuth-teren",
    content: "Március 20-án délután közösségi találkozót szervezünk a Kossuth téren, ahol a választók kérdéseket tehetnek fel és megbeszélhetjük Budapest jövőjét. Minden érdeklődőt szeretettel várunk! Programok: 14:00 - Megnyitó, 14:30 - Kérdések és válaszok, 16:00 - Kötetlen beszélgetés",
    excerpt: "Március 20-án közösségi találkozó a Kossuth téren - minden választót várunk!",
    status: "PUBLISHED",
    category: "Események",
    imageUrl: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?fit=crop&crop=center",
    createdAt: "2025-09-12T14:30:00Z",
    updatedAt: "2025-09-12T14:30:00Z"
  },
  {
    id: "mock-e2",
    title: "Családi nap a Városligetben",
    slug: "csaladi-nap-a-varosligetben",
    content: "Április 1-jén családi napot szervezünk a Városligetben. Programok gyerekeknek és felnőtteknek: arcfestés, kézműves foglalkozások, sport versenyek és politikai kvíz. Ingyenes belépés mindenki számára!",
    excerpt: "Április 1-jén családi nap a Városligetben - ingyenes programokkal mindenkinek.",
    status: "PUBLISHED",
    category: "Események",
    imageUrl: "https://images.unsplash.com/photo-1530549387789-4c1017266635?fit=crop&crop=center",
    createdAt: "2025-09-14T16:00:00Z",
    updatedAt: "2025-09-14T16:00:00Z"
  },
  {
    id: "mock-e3",
    title: "Ifjúsági fórum a Parlament előtt",
    slug: "ifjusagi-forum-parlament-elott",
    content: "Április 15-én 16:00-tól ifjúsági fórumot tartunk a Parlament előtt. Fiatalok kérdezhetnek az oktatásról, munkalehetőségekről és a jövő terveiről. Jelentkezés kötelező: ifjusag@lovas2024.hu címen. Résztvevők száma korlátozott - 200 fő.",
    excerpt: "Április 15-én ifjúsági fórum a Parlamentnél - oktatás, munka, jövő témákban.",
    status: "PUBLISHED",
    category: "Események",
    imageUrl: "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?fit=crop&crop=center",
    createdAt: "2025-09-20T10:15:00Z",
    updatedAt: "2025-09-20T10:15:00Z"
  },
  {
    id: "mock-e4",
    title: "Nyugdíjas klub találkozó - egészség és közösség",
    slug: "nyugdijas-klub-talalkozo-egeszseg-kozosseg",
    content: "Március 25-én 10:00-től nyugdíjas klub találkozót szervezünk a Városháza dísztermében. Témák: egészségmegőrzés, közösségi programok, digitális oktatás időseknek. Ingyenes egészségügyi szűrés is lesz. Regisztráció: +36-1-555-0123",
    excerpt: "Március 25-én nyugdíjas találkozó a Városházán - egészség, közösség, digitális oktatás.",
    status: "PUBLISHED",
    category: "Események",
    imageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?fit=crop&crop=center",
    createdAt: "2025-09-18T09:30:00Z",
    updatedAt: "2025-09-18T09:30:00Z"
  },
  {
    id: "mock-e5",
    title: "Vállalkozói reggeli - kisvállalkozások támogatása",
    slug: "vallalkozoi-reggeli-kisvallalkozasok-tamogatasa",
    content: "Április 3-án 8:00-tól vállalkozói reggelit tartunk a Budapest Kongresszusi Központban. Témák: pályázati lehetőségek, adókedvezmények, digitalizációs támogatások. Előadók: gazdasági miniszter, MFB képviselője. Jelentkezés kötelező korlátozott létszám miatt.",
    excerpt: "Április 3-án vállalkozói reggeli - pályázatok, adókedvezmények, digitalizáció témákban.",
    status: "PUBLISHED",
    category: "Események",
    imageUrl: null,
    createdAt: "2025-09-22T07:45:00Z",
    updatedAt: "2025-09-22T07:45:00Z"
  },

  // Közlemények (5 hír, 60% képpel)
  {
    id: "mock-k1",
    title: "Hivatalos közlemény - útlezárás a Váci úton",
    slug: "hivatalos-kozlemeny-utlezaras-a-vaci-uton",
    content: "Tájékoztatjuk a lakosságot, hogy március 25-től április 15-ig a Váci út egy szakaszán útfelújítási munkálatok miatt forgalomkorlátozásra kell számítani. A részletes térképet és alternatív útvonalakat a honlapunkon találják.",
    excerpt: "Útlezárás és forgalomkorlátozás március 25-től április 15-ig a Váci úton.",
    status: "PUBLISHED",
    category: "Közlemények",
    imageUrl: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?fit=crop&crop=center",
    createdAt: "2025-09-10T09:15:00Z",
    updatedAt: "2025-09-10T09:15:00Z"
  },
  {
    id: "mock-k2",
    title: "Változások a képviselői fogadóórákban",
    slug: "valtozasok-a-kepviseloi-fogadoorakan",
    content: "Április 1-től módosulnak a képviselői fogadóórák időpontjai. Új időpontok: kedd 9-12, csütörtök 14-17, szombat 10-13. Előzetes időpontfoglalás szükséges a +36-1-234-5678 telefonszámon.",
    excerpt: "Módosulnak a fogadóórák időpontjai április 1-től - előzetes időpontfoglalás szükséges.",
    status: "PUBLISHED",
    category: "Közlemények",
    imageUrl: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?fit=crop&crop=center",
    createdAt: "2025-09-11T11:30:00Z",
    updatedAt: "2025-09-11T11:30:00Z"
  },
  {
    id: "mock-k3",
    title: "Parkolási rendszer változások a belvárosban",
    slug: "parkolasi-rendszer-valtozasok-belvarosban",
    content: "Március 1-től új parkolási zónák lépnek életbe a belvárosban. A P+R parkolók használata ingyenes lesz BKV bérlettel. Új parkolóházak épülnek a Deák téren és a Kálvin téren. Részletes információ a budapest.hu oldalon.",
    excerpt: "Új parkolási zónák és ingyenes P+R március 1-től - új parkolóházak építése.",
    status: "PUBLISHED",
    category: "Közlemények",
    imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?fit=crop&crop=center",
    createdAt: "2025-09-26T14:20:00Z",
    updatedAt: "2025-09-26T14:20:00Z"
  },
  {
    id: "mock-k4",
    title: "Közüzemi díjak befagyasztása 2024-ben",
    slug: "kozuzemi-dijak-befagyasztasa-2024-ben",
    content: "A kormány döntése értelmében befagyasztjuk a közüzemi díjakat 2024 egész évére. Ez érinti a gáz-, áram-, víz- és távfűtési díjakat. A családok átlagosan évi 120.000 forintot takaríthatnak meg. A rendelet március 1-én lép hatályba.",
    excerpt: "Közüzemi díjak befagyasztása 2024-re - átlag 120.000 Ft megtakarítás családonként.",
    status: "PUBLISHED",
    category: "Közlemények",
    imageUrl: null,
    createdAt: "2025-09-22T12:00:00Z",
    updatedAt: "2025-09-22T12:00:00Z"
  },
  {
    id: "mock-k5",
    title: "Hulladékgyűjtés ütemezésének változása húsvét idején",
    slug: "hulladekgyujtes-utemezese-valtozas-husvet",
    content: "Húsvét hosszú hétvégéje miatt módosul a hulladékgyűjtés ütemezése március 28-31. között. A szombati gyűjtés péntekre kerül előre, a hétfői gyűjtés kedden történik. Szelektív hulladék gyűjtése változatlan marad. Kérjük, figyeljenek az új időpontokra!",
    excerpt: "Húsvéti hulladékgyűjtés változás: szombat→péntek, hétfő→kedd március 28-31.",
    status: "PUBLISHED",
    category: "Közlemények",
    imageUrl: null,
    createdAt: "2025-09-15T08:30:00Z",
    updatedAt: "2025-09-15T08:30:00Z"
  },

  // Sajtóközlemények (5 hír, 80% képpel)
  {
    id: "mock-s1",
    title: "Sajtóközlemény: Új szociális támogatási program",
    slug: "sajtokovlemeny-uj-szocialis-tamogatasi-program",
    content: "Ma bejelentettük az új szociális támogatási programunkat, amely havonta 50.000 forint támogatást nyújt a rászorulóknak. A program 10.000 családot érint és március 1-től igényelhető. Részletek és jelentkezési lap az önkormányzati honlapon.",
    excerpt: "Új szociális program: havi 50.000 Ft támogatás 10.000 család számára március 1-től.",
    status: "PUBLISHED",
    category: "Sajtóközlemények",
    imageUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?fit=crop&crop=center",
    createdAt: "2025-09-25T13:00:00Z",
    updatedAt: "2025-09-25T13:00:00Z"
  },
  {
    id: "mock-s2",
    title: "Sajtóközlemény: Megállapodás az ingyenes tömegközlekedésről",
    slug: "sajtokozvemeny-megallapodas-ingyenes-tomegkozlekedesrol",
    content: "Történelmi megállapodást írtunk alá a BKV-val az ingyenes tömegközlekedésről. Szeptember 1-től minden 65 év feletti budapesti lakos ingyen utazhat. A program 300.000 embert érint és évi 2 milliárd forint megtakarítást jelent a családoknak.",
    excerpt: "Ingyenes tömegközlekedés szeptember 1-től minden 65+ budapesti lakos számára.",
    status: "PUBLISHED",
    category: "Sajtóközlemények",
    imageUrl: null,
    createdAt: "2025-09-28T15:45:00Z",
    updatedAt: "2025-09-28T15:45:00Z"
  },
  {
    id: "mock-s3",
    title: "Sajtóközlemény: 1000 milliárd forint gazdaságfejlesztési csomag",
    slug: "sajtokozvemeny-1000-milliard-gazdasagfejlesztesi-csomag",
    content: "Bejelentettük az új gazdaságfejlesztési csomagot, amely 1000 milliárd forint értékben támogatja a magyar vállalkozásokat. A program 5 évre szól és 200.000 új munkahelyet teremt. Kiemelt figyelmet kap a digitalizáció, zöld energia és innováció.",
    excerpt: "1000 milliárd Ft gazdaságfejlesztési csomag - 200.000 új munkahely 5 év alatt.",
    status: "PUBLISHED",
    category: "Sajtóközlemények",
    imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?fit=crop&crop=center",
    createdAt: "2025-09-05T11:00:00Z",
    updatedAt: "2025-09-05T11:00:00Z"
  },
  {
    id: "mock-s4",
    title: "Sajtóközlemény: Lakhatási támogatás fiatal családoknak",
    slug: "sajtokozvemeny-lakhatasi-tamogatas-fiatal-csaladoknak",
    content: "A kormány új lakhatási támogatási programot indít 35 év alatti családok számára. 0%-os kamatozású hitel 15 millió forintig, valamint 5 millió forint vissza nem térítendő támogatás első lakásvásárláshoz. A program április 1-től igényelhető.",
    excerpt: "0% kamat + 5M Ft támogatás fiatal családoknak első lakásvásárláshoz április 1-től.",
    status: "PUBLISHED",
    category: "Sajtóközlemények",
    imageUrl: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?fit=crop&crop=center",
    createdAt: "2025-09-18T14:15:00Z",
    updatedAt: "2025-09-18T14:15:00Z"
  },
  {
    id: "mock-s5",
    title: "Sajtóközlemény: Történelmi egyetemfejlesztési beruházás",
    slug: "sajtokozvemeny-tortenelmi-egyetemfejlesztesi-beruhazas",
    content: "500 milliárd forint értékű egyetemfejlesztési programot indítunk. Új campusok épülnek, modern laborok és kutatóintézetek létesülnek. 50.000 új egyetemi férőhely és 10.000 új oktatói állás. A program 2030-ig tart, nemzetközi együttműködésekkel.",
    excerpt: "500 milliárd Ft egyetemfejlesztés - 50.000 új férőhely, 10.000 új oktató 2030-ig.",
    status: "PUBLISHED",
    category: "Sajtóközlemények",
    imageUrl: null,
    createdAt: "2025-09-08T16:30:00Z",
    updatedAt: "2025-09-08T16:30:00Z"
  },

  // Kampány (5 hír, 80% képpel)
  {
    id: "mock-ka1",
    title: "Kampánynyitó rendezvény - Egy jobb Budapest mindenkinek",
    slug: "kampanynyito-rendezveny-egy-jobb-budapest-mindenkinek",
    content: "Március 30-án tartjuk kampánynyitó rendezvényünket a Hősök terén. 'Egy jobb Budapest mindenkinek' mottóval mutatjuk be programunkat. Vendégek: helyi képviselők, civil szervezetek vezetői és Ti, a választók. Kezdés: 18:00",
    excerpt: "Március 30-án kampánynyitó a Hősök terén - 'Egy jobb Budapest mindenkinek' mottóval.",
    status: "PUBLISHED",
    category: "Kampány",
    imageUrl: "https://images.unsplash.com/photo-1557804506-669a67965ba0?fit=crop&crop=center",
    createdAt: "2025-09-16T17:00:00Z",
    updatedAt: "2025-09-16T17:00:00Z"
  },
  {
    id: "mock-ka2",
    title: "Önkéntes jelentkezés a kampánycsapatba",
    slug: "onkentes-jelentkezes-a-kampanycsapatba",
    content: "Csatlakozz hozzánk! Keresünk lelkes önkénteseket a kampánycsapatunkba. Feladatok: szórólapozás, rendezvényszervezés, közösségi média kezelés. Jelentkezni lehet a info@lovas2024.hu emailen vagy a +36-30-123-4567 telefonon.",
    excerpt: "Csatlakozz a kampánycsapatunkhoz! Önkéntes jelentkezés több területen.",
    status: "PUBLISHED",
    category: "Kampány",
    imageUrl: null,
    createdAt: "2025-09-13T12:00:00Z",
    updatedAt: "2025-09-13T12:00:00Z"
  },
  {
    id: "mock-ka3",
    title: "Kampánybusz indul - járjuk be együtt Budapestet",
    slug: "kampanybusz-indul-jarjuk-be-egyutt-budapestet",
    content: "Április 5-től kampánybusz indul, amely minden budapesti kerületet meglátogat. A kampánybusz minden nap más helyszínen áll meg, ahol személyesen találkozhattok velem. Programok 10:00-18:00 között. Részletes útvonal a honlapon.",
    excerpt: "Kampánybusz indul április 5-től - minden kerületben személyes találkozó lehetőség.",
    status: "PUBLISHED",
    category: "Kampány",
    imageUrl: "https://images.unsplash.com/photo-1494522358652-f30e61a5de15?fit=crop&crop=center",
    createdAt: "2025-09-25T09:30:00Z",
    updatedAt: "2025-09-25T09:30:00Z"
  },
  {
    id: "mock-ka4",
    title: "Egyetemista kampány - fiataloknak fiatalok",
    slug: "egyetemista-kampany-fiataloknak-fiatalok",
    content: "Egyetemi kampányt indítunk a főváros összes felsőoktatási intézményében. Fiatal önkéntesek viszik el a programunkat a kampuszokra. Különleges ifjúsági programpontok: ösztöndíjak, kollégiumi férőhelyek, gyakornoki lehetőségek. Minden egyetemen lesz stand.",
    excerpt: "Egyetemi kampány indul - fiatal önkéntesek viszik el a programot a kampuszokra.",
    status: "PUBLISHED",
    category: "Kampány",
    imageUrl: null,
    createdAt: "2025-09-21T15:20:00Z",
    updatedAt: "2025-09-21T15:20:00Z"
  },
  {
    id: "mock-ka5",
    title: "Családi kampányprogram - gyerekekkel a politikáról",
    slug: "csaladi-kampanyprogram-gyerekekkel-politikarol",
    content: "Különleges családi kampányprogramot szervezünk, ahol gyerekekkel is beszélgetünk a városfejlesztésről. Játszóterek, iskolák, biztonság - ezek a témák. Gyerekbarát formátumban magyarázzuk el a politikai döntések fontosságát. Minden hétvégén más helyszín.",
    excerpt: "Családi kampány gyerekekkel - játszóterek, iskolák, biztonság témákban.",
    status: "PUBLISHED",
    category: "Kampány",
    imageUrl: null,
    createdAt: "2025-09-19T11:45:00Z",
    updatedAt: "2025-09-19T11:45:00Z"
  }
].map(post => ({
  ...post,
  newsCategory: post.category ? {
    id: post.category,
    name: post.category,
    color: NEWS_CATEGORY_COLORS[post.category as keyof typeof NEWS_CATEGORY_COLORS]?.primary || "#6b7280"
  } : undefined
}));

// GET - Egy bejegyzés lekérése
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // First, try to find the post in the database
    let post;
    try {
      post = await prisma.post.findUnique({
        where: { id },
        include: {
          newsCategory: true, // Include category data for theme integration
        },
      });
    } catch (dbError) {
      console.log("[POST_GET] Database error, will check mock data");
    }

    // If not found in database, check mock posts
    if (!post) {
      const mockPost = mockPosts.find(p => p.id === id);
      if (mockPost) {
        return NextResponse.json(mockPost);
      }
    }

    if (!post) {
      return new NextResponse("Bejegyzés nem található", { status: 404 });
    }

    return NextResponse.json(post);
  } catch (error) {
    console.error("[POST_GET]", error);
    return new NextResponse("Hiba történt", { status: 500 });
  }
}

// PATCH - Bejegyzés módosítása
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // Ha változott a cím, generáljunk új slug-ot
    const slug = body.title ? generateSlug(body.title) : undefined;

    const post = await prisma.post.update({
      where: { id },
      data: {
        title: body.title,
        content: body.content,
        slug: slug,
        status: body.status,
        imageUrl: body.imageUrl,
      },
    });

    return NextResponse.json(post);
  } catch (error) {
    console.error("[POST_PATCH]", error);
    return new NextResponse("Hiba történt a módosítás során", { status: 500 });
  }
}

// DELETE - Bejegyzés törlése
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await prisma.post.delete({
      where: { id },
    });

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error("[POST_DELETE]", error);
    return new NextResponse("Hiba történt a törlés során", { status: 500 });
  }
}

"use strict";exports.id=4872,exports.ids=[4872],exports.modules={20471:(e,t,r)=>{r.d(t,{Lf:()=>n,TE:()=>d,TR:()=>p,e6:()=>c,iM:()=>m,o2:()=>g,zO:()=>a});var o=r(2723),s=r(55245);let l=null;async function n(e){try{console.log("Email k\xfcld\xe9s kezd\xe9se...",{to:"lovas.zoltan1986@gmail.com",environment:"production",resendAvailable:!!l});let{name:t,email:r,subject:o,message:s,phone:n,district:a,preferredContact:d}=e,c=`
      <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #1a365d;">\xdaj kapcsolatfelv\xe9teli \xfczenet \xe9rkezett</h2>
        
        <div style="background-color: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Felad\xf3 neve:</strong> ${t}</p>
          <p><strong>Email c\xedme:</strong> ${r}</p>
          ${n?`<p><strong>Telefonsz\xe1m:</strong> ${n}</p>`:""}
          ${a?`<p><strong>Ker\xfclet:</strong> ${a}</p>`:""}
          ${d?`<p><strong>Prefer\xe1lt kapcsolattart\xe1s:</strong> ${d}</p>`:""}
          <p><strong>T\xe1rgy:</strong> ${o}</p>
          <p style="margin-top: 20px;"><strong>\xdczenet:</strong></p>
          <p style="white-space: pre-wrap;">${s}</p>
        </div>
        
        <p style="color: #718096; font-size: 14px;">
          Ez egy automatikus \xe9rtes\xedt\xe9s a weboldal kapcsolatfelv\xe9teli űrlapj\xe1r\xf3l.
        </p>
      </div>
    `,x={from:"Lovas Zolt\xe1n <noreply@lovaszoltan.dev>",to:"lovas.zoltan1986@gmail.com",subject:`\xdaj \xfczenet: ${o}`,html:c,replyTo:r},m=i();if(m)try{let e=await m.sendMail({...x,from:`"Lovas Zolt\xe1n" <${process.env.GMAIL_USER}>`});return console.log("✅ Gmail SMTP - Email sikeresen elk\xfcldve!"),console.log(`📬 Email ID: ${e.messageId}`),{success:!0}}catch(e){console.error("Gmail SMTP k\xfcld\xe9si hiba:",e)}if(l)try{let e=await l.emails.send(x);return console.log("✅ Resend - Email sikeresen elk\xfcldve!"),console.log("Resend email eredm\xe9nye:",e),{success:!0}}catch(e){console.error("Resend k\xfcld\xe9si hiba:",e)}return console.log("❌ Egyetlen email szolg\xe1ltat\xe1s sem el\xe9rhető!"),console.log(`📧 EMAIL PREVIEW (csak konzol):`),console.log(`To: ${x.to}`),console.log(`Subject: ${x.subject}`),console.log(`From: ${x.from}`),console.log(`Reply-To: ${x.replyTo}`),console.log("---"),console.log(`🔧 Konfigur\xe1lja a Gmail SMTP-t vagy Resend API-t val\xf3s email k\xfcld\xe9shez!`),{success:!0}}catch(e){throw console.error("Email k\xfcld\xe9si hiba r\xe9szletek:",{error:e instanceof Error?e.message:String(e),code:e instanceof Error&&"code"in e?e.code:void 0,statusCode:e instanceof Error&&"statusCode"in e?e.statusCode:void 0}),e}}function i(){return process.env.GMAIL_USER&&process.env.GMAIL_APP_PASSWORD?s.createTransport({service:"gmail",auth:{user:process.env.GMAIL_USER,pass:process.env.GMAIL_APP_PASSWORD}}):(console.log("Gmail credentials not configured"),null)}async function a(e){try{console.log("H\xedrlev\xe9l megerős\xedtő email k\xfcld\xe9se...",{to:e.email,environment:"production",resendAvailable:!!l});let{name:t,email:r}=e,o=`${process.env.NEXTAUTH_URL||"http://localhost:3000"}/newsletter/unsubscribe?email=${encodeURIComponent(r)}`,s=`
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 20px; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 28px; font-weight: 300;">📧 H\xedrlev\xe9l Feliratkoz\xe1s</h1>
          <p style="color: #f0f4f8; margin: 10px 0 0 0; font-size: 16px;">Megerős\xedtj\xfck a feliratkoz\xe1s\xe1t</p>
        </div>
        
        <div style="padding: 40px 20px;">
          <h2 style="color: #2d3748; margin-bottom: 20px;">Kedves ${t}!</h2>
          
          <p style="color: #4a5568; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            K\xf6sz\xf6nj\xfck, hogy feliratkozott h\xedrlevel\xfcnkre! Ez az email megerős\xedti, hogy sikeresen feliratkoztattuk \xd6nt a k\xf6vetkező email c\xedmmel:
          </p>
          
          <div style="background-color: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea;">
            <p style="margin: 0; color: #2d3748; font-weight: 600;">📧 ${r}</p>
          </div>
          
          <h3 style="color: #2d3748; margin-top: 30px; margin-bottom: 15px;">Mit fog kapni?</h3>
          <ul style="color: #4a5568; font-size: 15px; line-height: 1.6; padding-left: 20px;">
            <li style="margin-bottom: 8px;">🗞️ \xdaj h\xedrek \xe9s cikkek \xe9rtes\xedt\xe9sei</li>
            <li style="margin-bottom: 8px;">📅 K\xf6zelgő esem\xe9nyek \xe9s programok</li>
            <li style="margin-bottom: 8px;">🏛️ Politikai fejlem\xe9nyek \xe9s \xe1ll\xe1spontok</li>
            <li style="margin-bottom: 8px;">🤝 K\xf6z\xf6ss\xe9gi esem\xe9nyek megh\xedv\xf3i</li>
          </ul>
          
          <div style="background-color: #edf2f7; padding: 20px; border-radius: 8px; margin: 30px 0;">
            <h4 style="color: #2d3748; margin: 0 0 10px 0; font-size: 16px;">🔒 Adatv\xe9delem</h4>
            <p style="color: #4a5568; font-size: 14px; margin: 0; line-height: 1.5;">
              Az \xd6n email c\xedm\xe9t bizalmasan kezelj\xfck \xe9s csak h\xedrlev\xe9l k\xfcld\xe9sre haszn\xe1ljuk. 
              Adatait nem adjuk \xe1t harmadik f\xe9lnek. GDPR megfelelően b\xe1rmikor leiratkozhat.
            </p>
          </div>
          
          <div style="text-align: center; margin: 40px 0;">
            <p style="color: #718096; font-size: 14px; margin: 0;">
              Ha nem k\xedv\xe1n t\xf6bb h\xedrlevelet kapni, 
              <a href="${o}" style="color: #667eea; text-decoration: none; font-weight: 600;">
                itt leiratkozhat
              </a>
            </p>
          </div>
        </div>
        
        <div style="background-color: #f7fafc; padding: 20px; text-align: center; border-top: 1px solid #e2e8f0;">
          <p style="color: #718096; font-size: 12px; margin: 0;">
            Ezt az emailt automatikusan k\xfcldte a Lovas Zolt\xe1n politikai oldal rendszere.
          </p>
          <p style="color: #718096; font-size: 12px; margin: 5px 0 0 0;">
            <a href="${o}" style="color: #667eea; text-decoration: none;">Leiratkoz\xe1s</a>
          </p>
        </div>
      </div>
    `,n={from:process.env.GMAIL_USER||"noreply@lovaszoltan.dev",to:r,replyTo:"lovas.zoltan1986@gmail.com",subject:"✅ H\xedrlev\xe9l feliratkoz\xe1s megerős\xedt\xe9se - Lovas Zolt\xe1n",html:s,text:`
Kedves ${t}!

K\xf6sz\xf6nj\xfck, hogy feliratkozott h\xedrlevel\xfcnkre!

Ez az email megerős\xedti, hogy sikeresen feliratkozott a k\xf6vetkező email c\xedmmel: ${r}

Mit fog kapni:
- \xdaj h\xedrek \xe9s cikkek \xe9rtes\xedt\xe9sei
- K\xf6zelgő esem\xe9nyek \xe9s programok  
- Politikai fejlem\xe9nyek \xe9s \xe1ll\xe1spontok
- K\xf6z\xf6ss\xe9gi esem\xe9nyek megh\xedv\xf3i

Adatv\xe9delem: Az \xd6n email c\xedm\xe9t bizalmasan kezelj\xfck \xe9s csak h\xedrlev\xe9l k\xfcld\xe9sre haszn\xe1ljuk. 

Ha nem k\xedv\xe1n t\xf6bb h\xedrlevelet kapni, leiratkozhat itt: ${o}

\xdcdv\xf6zlettel,
Lovas Zolt\xe1n csapata
      `};{let e=i();if(e)try{return await e.sendMail(n),console.log("✅ Gmail SMTP - H\xedrlev\xe9l megerős\xedtő email sikeresen elk\xfcldve!"),{success:!0}}catch(e){console.error("Gmail SMTP k\xfcld\xe9si hiba:",e)}}if(l)try{let e=await l.emails.send(n);return console.log("✅ Resend - H\xedrlev\xe9l megerős\xedtő email sikeresen elk\xfcldve!"),console.log("Resend email eredm\xe9nye:",e),{success:!0}}catch(e){console.error("Resend k\xfcld\xe9si hiba:",e)}return console.log("❌ H\xedrlev\xe9l megerős\xedtő email k\xfcld\xe9se sikertelen!"),console.log(`📧 NEWSLETTER CONFIRMATION EMAIL PREVIEW (csak konzol):`),console.log(`To: ${n.to}`),console.log(`Subject: ${n.subject}`),console.log(`From: ${n.from}`),{success:!1,error:"Email service unavailable"}}catch(e){return console.error("H\xedrlev\xe9l megerős\xedtő email k\xfcld\xe9si hiba:",e),{success:!1,error:"Failed to send confirmation email"}}}async function d(e){try{console.log("Leiratkoz\xe1s megerős\xedtő email k\xfcld\xe9se...",{to:e.email,environment:"production",resendAvailable:!!l});let{name:t,email:r}=e,o=`
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
        <div style="background: linear-gradient(135deg, #e53e3e 0%, #c53030 100%); padding: 40px 20px; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 28px; font-weight: 300;">📭 H\xedrlev\xe9l Leiratkoz\xe1s</h1>
          <p style="color: #fed7d7; margin: 10px 0 0 0; font-size: 16px;">Leiratkoz\xe1s megerős\xedt\xe9se</p>
        </div>
        
        <div style="padding: 40px 20px;">
          <h2 style="color: #2d3748; margin-bottom: 20px;">Kedves ${t}!</h2>
          
          <p style="color: #4a5568; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Ez az email megerős\xedti, hogy sikeresen leiratkozott a h\xedrlevel\xfcnkről. A k\xf6vetkező email c\xedm ker\xfclt elt\xe1vol\xedt\xe1sra:
          </p>
          
          <div style="background-color: #fed7d7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #e53e3e;">
            <p style="margin: 0; color: #2d3748; font-weight: 600;">📧 ${r}</p>
          </div>
          
          <div style="background-color: #f0fff4; padding: 20px; border-radius: 8px; margin: 30px 0; border-left: 4px solid #38a169;">
            <h4 style="color: #2d3748; margin: 0 0 10px 0; font-size: 16px;">✅ Leiratkoz\xe1s sikeres</h4>
            <p style="color: #4a5568; font-size: 14px; margin: 0; line-height: 1.5;">
              T\xf6bb\xe9 nem fog h\xedrlevelet kapni től\xfcnk. Adatait biztons\xe1gosan t\xe1roljuk, de newsletter \xfczeneteket nem k\xfcld\xfcnk.
            </p>
          </div>
          
          <div style="background-color: #edf2f7; padding: 20px; border-radius: 8px; margin: 30px 0;">
            <h4 style="color: #2d3748; margin: 0 0 10px 0; font-size: 16px;">💡 Meggondolta mag\xe1t?</h4>
            <p style="color: #4a5568; font-size: 14px; margin: 0; line-height: 1.5;">
              Ha k\xe9sőbb \xfajra szeretne feliratkozni, megteheti a <a href="${process.env.NEXTAUTH_URL||"http://localhost:3000"}/kapcsolat" style="color: #667eea; text-decoration: none; font-weight: 600;">kapcsolat oldalon</a> vagy a <a href="${process.env.NEXTAUTH_URL||"http://localhost:3000"}/profil" style="color: #667eea; text-decoration: none; font-weight: 600;">profil oldal\xe1n</a>.
            </p>
          </div>
        </div>
        
        <div style="background-color: #f7fafc; padding: 20px; text-align: center; border-top: 1px solid #e2e8f0;">
          <p style="color: #718096; font-size: 12px; margin: 0;">
            Ezt az emailt automatikusan k\xfcldte a Lovas Zolt\xe1n politikai oldal rendszere.
          </p>
        </div>
      </div>
    `,s={from:process.env.GMAIL_USER||"noreply@lovaszoltan.dev",to:r,replyTo:"lovas.zoltan1986@gmail.com",subject:"\uD83D\uDCED H\xedrlev\xe9l leiratkoz\xe1s megerős\xedt\xe9se - Lovas Zolt\xe1n",html:o,text:`
Kedves ${t}!

Ez az email megerős\xedti, hogy sikeresen leiratkozott a h\xedrlevel\xfcnkről.

Leiratkozott email c\xedm: ${r}

T\xf6bb\xe9 nem fog h\xedrlevelet kapni től\xfcnk. Adatait biztons\xe1gosan t\xe1roljuk, de newsletter \xfczeneteket nem k\xfcld\xfcnk.

Ha k\xe9sőbb \xfajra szeretne feliratkozni, megteheti a kapcsolat oldalon vagy a profil oldal\xe1n.

\xdcdv\xf6zlettel,
Lovas Zolt\xe1n csapata
      `};{let e=i();if(e)try{return await e.sendMail(s),console.log("✅ Gmail SMTP - Leiratkoz\xe1s megerős\xedtő email sikeresen elk\xfcldve!"),{success:!0}}catch(e){console.error("Gmail SMTP k\xfcld\xe9si hiba:",e)}}if(l)try{return await l.emails.send(s),console.log("✅ Resend - Leiratkoz\xe1s megerős\xedtő email sikeresen elk\xfcldve!"),{success:!0}}catch(e){console.error("Resend k\xfcld\xe9si hiba:",e)}return{success:!1,error:"Email service unavailable"}}catch(e){return console.error("Leiratkoz\xe1s megerős\xedtő email k\xfcld\xe9si hiba:",e),{success:!1,error:"Failed to send unsubscribe confirmation"}}}async function c(e){try{console.log("Admin \xe9rtes\xedtő email k\xfcld\xe9se leiratkoz\xe1sr\xf3l...",{to:"lovas.zoltan1986@gmail.com",environment:"production",resendAvailable:!!l});let{name:t,email:r,unsubscribeTime:o,action:s}=e,n=`
      <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #c53030;">📭 H\xedrlev\xe9l leiratkoz\xe1s t\xf6rt\xe9nt</h2>
        
        <div style="background-color: #fed7d7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #e53e3e;">
          <p><strong>Leiratkozott szem\xe9ly:</strong> ${t}</p>
          <p><strong>Email c\xedme:</strong> ${r}</p>
          <p><strong>Leiratkoz\xe1s időpontja:</strong> ${o}</p>
          ${s?`<p><strong>Művelet:</strong> ${s}</p>`:""}
        </div>
        
        <div style="background-color: #f7fafc; padding: 15px; border-radius: 6px; margin: 20px 0;">
          <p style="margin: 0; font-size: 14px; color: #4a5568;">
            <strong>Biztons\xe1gi inform\xe1ci\xf3:</strong> Ez az automatikus \xe9rtes\xedt\xe9s az\xe9rt j\xf6tt l\xe9tre, 
            hogy nyomon k\xf6vethesd a h\xedrlev\xe9l feliratkoz\xe1sok v\xe1ltoz\xe1sait.
          </p>
        </div>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #e2e8f0;">
        <p style="font-size: 12px; color: #718096;">
          Automatikus \xe9rtes\xedt\xe9s a Lovas Zolt\xe1n politikai oldal rendszer\xe9től.
        </p>
      </div>
    `,a={from:process.env.GMAIL_USER||"noreply@lovaszoltan.dev",to:"lovas.zoltan1986@gmail.com",replyTo:"lovas.zoltan1986@gmail.com",subject:"\uD83D\uDCED ADMIN: H\xedrlev\xe9l leiratkoz\xe1s - "+r,html:n,text:`
H\xcdRLEV\xc9L LEIRATKOZ\xc1S

Leiratkozott szem\xe9ly: ${t}
Email c\xedme: ${r}
Leiratkoz\xe1s időpontja: ${o}
${s?`Művelet: ${s}`:""}

Ez az automatikus \xe9rtes\xedt\xe9s az\xe9rt j\xf6tt l\xe9tre, hogy nyomon k\xf6vethesd a h\xedrlev\xe9l feliratkoz\xe1sok v\xe1ltoz\xe1sait.
      `};{let e=i();if(e)try{return await e.sendMail(a),console.log("✅ Gmail SMTP - Admin leiratkoz\xe1s \xe9rtes\xedtő elk\xfcldve!"),{success:!0}}catch(e){console.error("Gmail SMTP k\xfcld\xe9si hiba:",e)}}if(l)try{return await l.emails.send(a),console.log("✅ Resend - Admin leiratkoz\xe1s \xe9rtes\xedtő elk\xfcldve!"),{success:!0}}catch(e){console.error("Resend k\xfcld\xe9si hiba:",e)}return{success:!1,error:"Email service unavailable"}}catch(e){return console.error("Admin leiratkoz\xe1s \xe9rtes\xedtő k\xfcld\xe9si hiba:",e),{success:!1,error:"Failed to send admin notification"}}}function x(){return process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASS?s.createTransport({host:process.env.SMTP_HOST,port:parseInt(process.env.SMTP_PORT||"587"),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}}):(console.log("SMTP credentials not configured"),null)}async function m(e,t,r,o,s){try{let n=`http://192.168.1.129:3001/peticiok/${s}/verify?token=${o}`;console.log("Pet\xedci\xf3 hiteles\xedt\xe9s email k\xfcld\xe9se...",{to:e,petitionTitle:r,verificationUrl:n,environment:"production"});let a=`
      <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="margin: 0; font-size: 24px;">Pet\xedci\xf3 Al\xe1\xedr\xe1s Megerős\xedt\xe9se</h1>
        </div>
        
        <div style="padding: 30px; background-color: white;">
          <p style="font-size: 16px; color: #333;">Kedves ${t}!</p>
          
          <p style="color: #666;">K\xf6sz\xf6nj\xfck, hogy al\xe1\xedrta a k\xf6vetkező pet\xedci\xf3t:</p>
          
          <div style="background-color: #f8f9fa; padding: 20px; border-left: 4px solid #667eea; margin: 20px 0;">
            <strong style="color: #333; font-size: 16px;">${r}</strong>
          </div>
          
          <p style="color: #666;">Az al\xe1\xedr\xe1s aktiv\xe1l\xe1s\xe1hoz k\xe9rj\xfck, kattintson az al\xe1bbi gombra:</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${n}" 
               style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                      color: white; text-decoration: none; padding: 15px 30px; border-radius: 6px; 
                      font-weight: bold; font-size: 16px;">
              Al\xe1\xedr\xe1s Megerős\xedt\xe9se
            </a>
          </div>
          
          <p style="color: #666; font-size: 14px;">Ha a gomb nem műk\xf6dik, m\xe1solja be ezt a linket a b\xf6ng\xe9szőj\xe9be:</p>
          <p style="word-break: break-all; color: #667eea; background-color: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 14px;">${n}</p>
          
          <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; border-radius: 4px; padding: 15px; margin: 20px 0;">
            <p style="margin: 0; color: #856404;"><strong>Fontos:</strong> Ez a link 24 \xf3r\xe1n bel\xfcl lej\xe1r. Ha nem erős\xedti meg al\xe1\xedr\xe1s\xe1t ezen időn bel\xfcl, \xfajra kell al\xe1\xedrnia a pet\xedci\xf3t.</p>
          </div>
          
          <p style="color: #666; font-size: 14px;">Ha nem \xd6n \xedrta al\xe1 ezt a pet\xedci\xf3t, k\xe9rj\xfck, hagyja figyelmen k\xedv\xfcl ezt az emailt.</p>
        </div>
        
        <div style="background-color: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 12px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0;">Ez egy automatikus email. K\xe9rj\xfck, ne v\xe1laszoljon r\xe1.</p>
          <p style="margin: 5px 0 0 0;">\xa9 ${new Date().getFullYear()} Lovas Zolt\xe1n Gy\xf6rgy - Politikai Platform</p>
        </div>
      </div>
    `,d={from:'"Lovas Zolt\xe1n Pet\xedci\xf3k" <petition@example.com>',to:e,subject:`Pet\xedci\xf3 al\xe1\xedr\xe1s megerős\xedt\xe9se - ${r}`,html:a,text:`
Kedves ${t}!

K\xf6sz\xf6nj\xfck, hogy al\xe1\xedrta a k\xf6vetkező pet\xedci\xf3t:
${r}

Az al\xe1\xedr\xe1s aktiv\xe1l\xe1s\xe1hoz kattintson az al\xe1bbi linkre:
${n}

Fontos: Ez a link 24 \xf3r\xe1n bel\xfcl lej\xe1r.

Ha nem \xd6n \xedrta al\xe1 ezt a pet\xedci\xf3t, k\xe9rj\xfck, hagyja figyelmen k\xedv\xfcl ezt az emailt.

\xa9 ${new Date().getFullYear()} Lovas Zolt\xe1n Gy\xf6rgy - Politikai Platform
      `},c=i();if(c)try{let t=await c.sendMail({...d,from:`"Lovas Zolt\xe1n Pet\xedci\xf3k" <${process.env.GMAIL_USER}>`});return console.log("✅ Gmail SMTP - Email sikeresen elk\xfcldve!"),console.log(`📬 Email ID: ${t.messageId}`),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("Gmail SMTP k\xfcld\xe9si hiba:",e)}let m=x();if(m)try{let t=await m.sendMail(d);return console.log("✅ SMTP - Email sikeresen elk\xfcldve!"),console.log(`📬 Email ID: ${t.messageId}`),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("SMTP k\xfcld\xe9si hiba:",e)}if(l)try{let t=await l?.emails.send({from:"Lovas Zolt\xe1n Pet\xedci\xf3k <onboarding@resend.dev>",to:e,subject:`Pet\xedci\xf3 al\xe1\xedr\xe1s megerős\xedt\xe9se - ${r}`,html:a});return console.log("✅ Resend - Email sikeresen elk\xfcldve!"),console.log("Resend email eredm\xe9nye:",t),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("Resend k\xfcld\xe9si hiba:",e)}return console.log("❌ Egyetlen email szolg\xe1ltat\xe1s sem el\xe9rhető!"),console.log(`📧 EMAIL PREVIEW (csak konzol):`),console.log(`To: ${e}`),console.log(`Subject: Pet\xedci\xf3 al\xe1\xedr\xe1s megerős\xedt\xe9se - ${r}`),console.log(`Verification URL: ${n}`),console.log("---"),console.log(`🔧 Konfigur\xe1lja a Gmail SMTP-t vagy Resend API-t val\xf3s email k\xfcld\xe9shez!`),{success:!0}}catch(t){return console.error("Pet\xedci\xf3 hiteles\xedt\xe9s email k\xfcld\xe9si hiba:",{error:t instanceof Error?t.message:String(t),email:e,petitionTitle:r}),{success:!1}}}async function g(e,t,r,o,s,n){try{let a=new Date(s).toLocaleDateString("hu-HU",{year:"numeric",month:"long",day:"numeric",weekday:"long"}),d=new Date(s).toLocaleTimeString("hu-HU",{hour:"2-digit",minute:"2-digit"}),c=new Date(n).toLocaleTimeString("hu-HU",{hour:"2-digit",minute:"2-digit"});console.log("Esem\xe9ny regisztr\xe1ci\xf3 email k\xfcld\xe9se...",{to:e,eventTitle:r,eventDate:a,environment:"production"});let m=`
      <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="margin: 0; font-size: 24px;">Esem\xe9ny Jelentkez\xe9s Megerős\xedt\xe9se</h1>
        </div>
        
        <div style="padding: 30px; background-color: white;">
          <p style="font-size: 16px; color: #333;">Kedves ${t}!</p>
          
          <p style="color: #666;">K\xf6sz\xf6nj\xfck, hogy jelentkezett a k\xf6vetkező esem\xe9nyre:</p>
          
          <div style="background-color: #f8f9fa; padding: 20px; border-left: 4px solid #667eea; margin: 20px 0;">
            <strong style="color: #333; font-size: 18px;">${r}</strong>
          </div>
          
          <div style="background-color: #e3f2fd; padding: 20px; border-radius: 6px; margin: 20px 0;">
            <h3 style="margin: 0 0 15px 0; color: #1976d2;">📅 Esem\xe9ny r\xe9szletei</h3>
            <div style="color: #333;">
              <p style="margin: 5px 0;"><strong>📅 D\xe1tum:</strong> ${a}</p>
              <p style="margin: 5px 0;"><strong>🕐 Időpont:</strong> ${d} - ${c}</p>
              <p style="margin: 5px 0;"><strong>📍 Helysz\xedn:</strong> ${o}</p>
            </div>
          </div>
          
          <div style="background-color: #e8f5e8; border: 1px solid #4caf50; border-radius: 4px; padding: 15px; margin: 20px 0;">
            <p style="margin: 0; color: #2e7d32;"><strong>✅ Jelentkez\xe9se megerős\xedtve!</strong></p>
            <p style="margin: 5px 0 0 0; color: #2e7d32;">V\xe1rjuk \xd6nt az esem\xe9nyen! K\xe9rj\xfck, \xe9rkezzen időben.</p>
          </div>
          
          <div style="background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 4px; padding: 15px; margin: 20px 0;">
            <p style="margin: 0; color: #856404;"><strong>💡 Fontos tudnival\xf3k:</strong></p>
            <ul style="margin: 10px 0 0 20px; color: #856404;">
              <li>K\xe9rj\xfck, \xe9rkezzen 10 perccel az esem\xe9ny kezdete előtt</li>
              <li>Hozza mag\xe1val ezt az email megerős\xedt\xe9st (mobilon is elegendő)</li>
              <li>V\xe1ltoz\xe1s eset\xe9n hamarosan \xe9rtes\xedtj\xfck</li>
            </ul>
          </div>
          
          <p style="color: #666; font-size: 14px; margin-top: 30px;">Ha k\xe9rd\xe9se van az esem\xe9nnyel kapcsolatban, ne habozzon kapcsolatba l\xe9pni vel\xfcnk!</p>
        </div>
        
        <div style="background-color: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 12px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0;">Ez egy automatikus email. K\xe9rj\xfck, ne v\xe1laszoljon r\xe1.</p>
          <p style="margin: 5px 0 0 0;">\xa9 ${new Date().getFullYear()} Lovas Zolt\xe1n Gy\xf6rgy - Politikai Platform</p>
        </div>
      </div>
    `,g={from:'"Lovas Zolt\xe1n Esem\xe9nyek" <events@example.com>',to:e,subject:`Esem\xe9ny jelentkez\xe9s megerős\xedtve - ${r}`,html:m,text:`
Kedves ${t}!

K\xf6sz\xf6nj\xfck, hogy jelentkezett a k\xf6vetkező esem\xe9nyre:
${r}

Esem\xe9ny r\xe9szletei:
📅 D\xe1tum: ${a}
🕐 Időpont: ${d} - ${c}
📍 Helysz\xedn: ${o}

✅ Jelentkez\xe9se megerős\xedtve!

Fontos tudnival\xf3k:
- K\xe9rj\xfck, \xe9rkezzen 10 perccel az esem\xe9ny kezdete előtt
- Hozza mag\xe1val ezt az email megerős\xedt\xe9st
- V\xe1ltoz\xe1s eset\xe9n hamarosan \xe9rtes\xedtj\xfck

\xa9 ${new Date().getFullYear()} Lovas Zolt\xe1n Gy\xf6rgy - Politikai Platform
      `},p=i();if(p)try{let t=await p.sendMail({...g,from:`"Lovas Zolt\xe1n Esem\xe9nyek" <${process.env.GMAIL_USER}>`});return console.log("✅ Gmail SMTP - Esem\xe9ny email sikeresen elk\xfcldve!"),console.log(`📬 Email ID: ${t.messageId}`),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("Gmail SMTP esem\xe9ny email k\xfcld\xe9si hiba:",e)}let f=x();if(f)try{let t=await f.sendMail(g);return console.log("✅ SMTP - Esem\xe9ny email sikeresen elk\xfcldve!"),console.log(`📬 Email ID: ${t.messageId}`),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("SMTP esem\xe9ny email k\xfcld\xe9si hiba:",e)}if(l)try{let t=await l?.emails.send({from:"Lovas Zolt\xe1n Esem\xe9nyek <onboarding@resend.dev>",to:e,subject:`Esem\xe9ny jelentkez\xe9s megerős\xedtve - ${r}`,html:m});return console.log("✅ Resend - Esem\xe9ny email sikeresen elk\xfcldve!"),console.log("Resend email eredm\xe9nye:",t),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("Resend esem\xe9ny email k\xfcld\xe9si hiba:",e)}return console.log("❌ Egyetlen email szolg\xe1ltat\xe1s sem el\xe9rhető!"),console.log(`📧 ESEM\xc9NY EMAIL PREVIEW (csak konzol):`),console.log(`To: ${e}`),console.log(`Subject: Esem\xe9ny jelentkez\xe9s megerős\xedtve - ${r}`),console.log(`Event: ${r} | ${a} ${d} | ${o}`),console.log("---"),console.log(`🔧 Konfigur\xe1lja a Gmail SMTP-t vagy Resend API-t val\xf3s email k\xfcld\xe9shez!`),{success:!0}}catch(t){return console.error("Esem\xe9ny regisztr\xe1ci\xf3 email k\xfcld\xe9si hiba:",{error:t instanceof Error?t.message:String(t),email:e,eventTitle:r}),{success:!1}}}async function p(e,t,r,o,s,n){try{let a=new Date(s).toLocaleDateString("hu-HU",{year:"numeric",month:"long",day:"numeric",weekday:"long"}),d=new Date(s).toLocaleTimeString("hu-HU",{hour:"2-digit",minute:"2-digit"}),c=new Date(n).toLocaleTimeString("hu-HU",{hour:"2-digit",minute:"2-digit"});console.log("Esem\xe9ny lemond\xe1s email k\xfcld\xe9se...",{to:e,eventTitle:r,eventDate:a,environment:"production"});let m=`
      <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #f56565 0%, #c53030 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="margin: 0; font-size: 24px;">Esem\xe9ny Jelentkez\xe9s Lemondva</h1>
        </div>
        
        <div style="padding: 30px; background-color: white;">
          <p style="font-size: 16px; color: #333;">Kedves ${t}!</p>
          
          <p style="color: #666;">Megerős\xedtj\xfck, hogy lemondta jelentkez\xe9s\xe9t a k\xf6vetkező esem\xe9nyről:</p>
          
          <div style="background-color: #fed7d7; padding: 20px; border-left: 4px solid #f56565; margin: 20px 0;">
            <strong style="color: #333; font-size: 18px;">${r}</strong>
          </div>
          
          <div style="background-color: #f7fafc; padding: 20px; border-radius: 6px; margin: 20px 0; border: 1px solid #e2e8f0;">
            <h3 style="margin: 0 0 15px 0; color: #4a5568;">📅 Esem\xe9ny r\xe9szletei</h3>
            <div style="color: #333;">
              <p style="margin: 5px 0;"><strong>📅 D\xe1tum:</strong> ${a}</p>
              <p style="margin: 5px 0;"><strong>🕐 Időpont:</strong> ${d} - ${c}</p>
              <p style="margin: 5px 0;"><strong>📍 Helysz\xedn:</strong> ${o}</p>
            </div>
          </div>
          
          <div style="background-color: #fed7d7; border: 1px solid #f56565; border-radius: 4px; padding: 15px; margin: 20px 0;">
            <p style="margin: 0; color: #c53030;"><strong>❌ Jelentkez\xe9se lemondva!</strong></p>
            <p style="margin: 5px 0 0 0; color: #c53030;">Nem vesz r\xe9szt az esem\xe9nyen. Helye felszabadult m\xe1sok sz\xe1m\xe1ra.</p>
          </div>
          
          <div style="background-color: #e6fffa; border: 1px solid #38b2ac; border-radius: 4px; padding: 15px; margin: 20px 0;">
            <p style="margin: 0; color: #285e61;"><strong>💚 \xdajra jelentkezhet!</strong></p>
            <p style="margin: 5px 0 0 0; color: #285e61;">Ha meggondolja mag\xe1t, b\xe1rmikor \xfajra jelentkezhet az esem\xe9nyre a weboldalunkon, am\xedg van szabad hely.</p>
          </div>
          
          <p style="color: #666; font-size: 14px; margin-top: 30px;">K\xf6sz\xf6nj\xfck, hogy figyelembe vette esem\xe9ny\xfcnket. Rem\xe9lj\xfck, tal\xe1lkozunk egy k\xf6vetkező alkalommal!</p>
        </div>
        
        <div style="background-color: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 12px; border-radius: 0 0 8px 8px;">
          <p style="margin: 0;">Ez egy automatikus email. K\xe9rj\xfck, ne v\xe1laszoljon r\xe1.</p>
          <p style="margin: 5px 0 0 0;">\xa9 ${new Date().getFullYear()} Lovas Zolt\xe1n Gy\xf6rgy - Politikai Platform</p>
        </div>
      </div>
    `,g={from:'"Lovas Zolt\xe1n Esem\xe9nyek" <events@example.com>',to:e,subject:`Esem\xe9ny lemond\xe1s megerős\xedtve - ${r}`,html:m,text:`
Kedves ${t}!

Megerős\xedtj\xfck, hogy lemondta jelentkez\xe9s\xe9t a k\xf6vetkező esem\xe9nyről:
${r}

Esem\xe9ny r\xe9szletei:
📅 D\xe1tum: ${a}
🕐 Időpont: ${d} - ${c}
📍 Helysz\xedn: ${o}

❌ Jelentkez\xe9se lemondva!

💚 \xdajra jelentkezhet!
Ha meggondolja mag\xe1t, b\xe1rmikor \xfajra jelentkezhet az esem\xe9nyre a weboldalunkon, am\xedg van szabad hely.

K\xf6sz\xf6nj\xfck, hogy figyelembe vette esem\xe9ny\xfcnket. Rem\xe9lj\xfck, tal\xe1lkozunk egy k\xf6vetkező alkalommal!

\xa9 ${new Date().getFullYear()} Lovas Zolt\xe1n Gy\xf6rgy - Politikai Platform
      `},p=i();if(p)try{let t=await p.sendMail({...g,from:`"Lovas Zolt\xe1n Esem\xe9nyek" <${process.env.GMAIL_USER}>`});return console.log("✅ Gmail SMTP - Esem\xe9ny lemond\xe1s email sikeresen elk\xfcldve!"),console.log(`📬 Email ID: ${t.messageId}`),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("Gmail SMTP esem\xe9ny lemond\xe1s email k\xfcld\xe9si hiba:",e)}let f=x();if(f)try{let t=await f.sendMail(g);return console.log("✅ SMTP - Esem\xe9ny lemond\xe1s email sikeresen elk\xfcldve!"),console.log(`📬 Email ID: ${t.messageId}`),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("SMTP esem\xe9ny lemond\xe1s email k\xfcld\xe9si hiba:",e)}if(l)try{let t=await l?.emails.send({from:"Lovas Zolt\xe1n Esem\xe9nyek <onboarding@resend.dev>",to:e,subject:`Esem\xe9ny lemond\xe1s megerős\xedtve - ${r}`,html:m});return console.log("✅ Resend - Esem\xe9ny lemond\xe1s email sikeresen elk\xfcldve!"),console.log("Resend email eredm\xe9nye:",t),console.log(`📧 Val\xf3s email elk\xfcldve a k\xf6vetkező c\xedmre: ${e}`),{success:!0}}catch(e){console.error("Resend esem\xe9ny lemond\xe1s email k\xfcld\xe9si hiba:",e)}return console.log("❌ Egyetlen email szolg\xe1ltat\xe1s sem el\xe9rhető!"),console.log(`📧 ESEM\xc9NY LEMOND\xc1S EMAIL PREVIEW (csak konzol):`),console.log(`To: ${e}`),console.log(`Subject: Esem\xe9ny lemond\xe1s megerős\xedtve - ${r}`),console.log(`Event: ${r} | ${a} ${d} | ${o}`),console.log("---"),console.log(`🔧 Konfigur\xe1lja a Gmail SMTP-t vagy Resend API-t val\xf3s email k\xfcld\xe9shez!`),{success:!0}}catch(t){return console.error("Esem\xe9ny lemond\xe1s email k\xfcld\xe9si hiba:",{error:t instanceof Error?t.message:String(t),email:e,eventTitle:r}),{success:!1}}}process.env.RESEND_API_KEY?(l=new o.R(process.env.RESEND_API_KEY),console.log("✅ Resend initialized with API key")):console.log("⚠️ RESEND_API_KEY not found in environment variables")},13538:(e,t,r)=>{r.d(t,{_:()=>s});var o=r(53524);let s=globalThis.prisma||new o.PrismaClient},2723:(e,t,r)=>{r.d(t,{R:()=>E});var o=Object.defineProperty,s=Object.defineProperties,l=Object.getOwnPropertyDescriptors,n=Object.getOwnPropertySymbols,i=Object.prototype.hasOwnProperty,a=Object.prototype.propertyIsEnumerable,d=(e,t,r)=>t in e?o(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,c=(e,t)=>{for(var r in t||(t={}))i.call(t,r)&&d(e,r,t[r]);if(n)for(var r of n(t))a.call(t,r)&&d(e,r,t[r]);return e},x=(e,t)=>s(e,l(t)),m=(e,t,r)=>new Promise((o,s)=>{var l=e=>{try{i(r.next(e))}catch(e){s(e)}},n=e=>{try{i(r.throw(e))}catch(e){s(e)}},i=e=>e.done?o(e.value):Promise.resolve(e.value).then(l,n);i((r=r.apply(e,t)).next())}),g=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){return yield this.resend.post("/api-keys",e,t)})}list(){return m(this,null,function*(){return yield this.resend.get("/api-keys")})}remove(e){return m(this,null,function*(){return yield this.resend.delete(`/api-keys/${e}`)})}},p=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){return yield this.resend.post("/audiences",e,t)})}list(){return m(this,null,function*(){return yield this.resend.get("/audiences")})}get(e){return m(this,null,function*(){return yield this.resend.get(`/audiences/${e}`)})}remove(e){return m(this,null,function*(){return yield this.resend.delete(`/audiences/${e}`)})}};function f(e){var t;return{attachments:null==(t=e.attachments)?void 0:t.map(e=>({content:e.content,filename:e.filename,path:e.path,content_type:e.contentType,inline_content_id:e.inlineContentId})),bcc:e.bcc,cc:e.cc,from:e.from,headers:e.headers,html:e.html,reply_to:e.replyTo,scheduled_at:e.scheduledAt,subject:e.subject,tags:e.tags,text:e.text,to:e.to}}var u=class{constructor(e){this.resend=e}send(e){return m(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return m(this,arguments,function*(e,t={}){let o=[];for(let t of e){if(t.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(7044).then(r.bind(r,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}t.html=yield this.renderAsync(t.react),t.react=void 0}o.push(f(t))}return yield this.resend.post("/emails/batch",o,t)})}},k=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(7044).then(r.bind(r,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/broadcasts",{name:e.name,audience_id:e.audienceId,preview_text:e.previewText,from:e.from,html:e.html,reply_to:e.replyTo,subject:e.subject,text:e.text},t)})}send(e,t){return m(this,null,function*(){return yield this.resend.post(`/broadcasts/${e}/send`,{scheduled_at:null==t?void 0:t.scheduledAt})})}list(){return m(this,null,function*(){return yield this.resend.get("/broadcasts")})}get(e){return m(this,null,function*(){return yield this.resend.get(`/broadcasts/${e}`)})}remove(e){return m(this,null,function*(){return yield this.resend.delete(`/broadcasts/${e}`)})}update(e,t){return m(this,null,function*(){return yield this.resend.patch(`/broadcasts/${e}`,{name:t.name,audience_id:t.audienceId,from:t.from,html:t.html,text:t.text,subject:t.subject,reply_to:t.replyTo,preview_text:t.previewText})})}},h=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){return yield this.resend.post(`/audiences/${e.audienceId}/contacts`,{unsubscribed:e.unsubscribed,email:e.email,first_name:e.firstName,last_name:e.lastName},t)})}list(e){return m(this,null,function*(){return yield this.resend.get(`/audiences/${e.audienceId}/contacts`)})}get(e){return m(this,null,function*(){return e.id||e.email?yield this.resend.get(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}update(e){return m(this,null,function*(){return e.id||e.email?yield this.resend.patch(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`,{unsubscribed:e.unsubscribed,first_name:e.firstName,last_name:e.lastName}):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}remove(e){return m(this,null,function*(){return e.id||e.email?yield this.resend.delete(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}},y=class{constructor(e){this.resend=e}create(e){return m(this,arguments,function*(e,t={}){return yield this.resend.post("/domains",{name:e.name,region:e.region,custom_return_path:e.customReturnPath},t)})}list(){return m(this,null,function*(){return yield this.resend.get("/domains")})}get(e){return m(this,null,function*(){return yield this.resend.get(`/domains/${e}`)})}update(e){return m(this,null,function*(){return yield this.resend.patch(`/domains/${e.id}`,{click_tracking:e.clickTracking,open_tracking:e.openTracking,tls:e.tls})})}remove(e){return m(this,null,function*(){return yield this.resend.delete(`/domains/${e}`)})}verify(e){return m(this,null,function*(){return yield this.resend.post(`/domains/${e}/verify`)})}},v=class{constructor(e){this.resend=e}send(e){return m(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return m(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(7044).then(r.bind(r,97044));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/emails",f(e),t)})}get(e){return m(this,null,function*(){return yield this.resend.get(`/emails/${e}`)})}update(e){return m(this,null,function*(){return yield this.resend.patch(`/emails/${e.id}`,{scheduled_at:e.scheduledAt})})}cancel(e){return m(this,null,function*(){return yield this.resend.post(`/emails/${e}/cancel`)})}},z="undefined"!=typeof process&&process.env&&process.env.RESEND_BASE_URL||"https://api.resend.com",b="undefined"!=typeof process&&process.env&&process.env.RESEND_USER_AGENT||"resend-node:4.8.0",E=class{constructor(e){if(this.key=e,this.apiKeys=new g(this),this.audiences=new p(this),this.batch=new u(this),this.broadcasts=new k(this),this.contacts=new h(this),this.domains=new y(this),this.emails=new v(this),!e&&("undefined"!=typeof process&&process.env&&(this.key=process.env.RESEND_API_KEY),!this.key))throw Error('Missing API key. Pass it to the constructor `new Resend("re_123")`');this.headers=new Headers({Authorization:`Bearer ${this.key}`,"User-Agent":b,"Content-Type":"application/json"})}fetchRequest(e){return m(this,arguments,function*(e,t={}){try{let r=yield fetch(`${z}${e}`,t);if(!r.ok)try{let e=yield r.text();return{data:null,error:JSON.parse(e)}}catch(t){if(t instanceof SyntaxError)return{data:null,error:{name:"application_error",message:"Internal server error. We are unable to process your request right now, please try again later."}};let e={message:r.statusText,name:"application_error"};if(t instanceof Error)return{data:null,error:x(c({},e),{message:t.message})};return{data:null,error:e}}return{data:yield r.json(),error:null}}catch(e){return{data:null,error:{name:"application_error",message:"Unable to fetch data. The request could not be resolved."}}}})}post(e,t){return m(this,arguments,function*(e,t,r={}){let o=new Headers(this.headers);r.idempotencyKey&&o.set("Idempotency-Key",r.idempotencyKey);let s=c({method:"POST",headers:o,body:JSON.stringify(t)},r);return this.fetchRequest(e,s)})}get(e){return m(this,arguments,function*(e,t={}){let r=c({method:"GET",headers:this.headers},t);return this.fetchRequest(e,r)})}put(e,t){return m(this,arguments,function*(e,t,r={}){let o=c({method:"PUT",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,o)})}patch(e,t){return m(this,arguments,function*(e,t,r={}){let o=c({method:"PATCH",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,o)})}delete(e,t){return m(this,null,function*(){let r={method:"DELETE",headers:this.headers,body:JSON.stringify(t)};return this.fetchRequest(e,r)})}}}};
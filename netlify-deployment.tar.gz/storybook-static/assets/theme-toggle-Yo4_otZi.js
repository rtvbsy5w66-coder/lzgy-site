import{a as h,j as e}from"./iframe-CH0y9Ln_.js";import{c as a}from"./createLucideIcon-DBITYvIf.js";/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=a("Moon",[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=a("Sun",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]);function c(){const{theme:t,setTheme:s}=h();return e.jsxs("button",{onClick:()=>s(t==="light"?"dark":"light"),className:"rounded-md p-2 hover:bg-gray-100 dark:hover:bg-gray-800",children:[t==="light"?e.jsx(o,{className:"h-5 w-5"}):e.jsx(m,{className:"h-5 w-5"}),e.jsx("span",{className:"sr-only",children:"Toggle theme"})]})}export{c as T};
